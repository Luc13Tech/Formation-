// ═══════════════════════════════════════════
// LUCKILY ACADEMY — i18n.js (FR/EN/ES/PT)
// ═══════════════════════════════════════════
'use strict';

let currentLang = localStorage.getItem('la_lang') || 'fr';

const T = {
  fr:{
    nav_home:'Accueil',nav_courses:'Formations',nav_about:'À propos',nav_contact:'Contact',nav_login:'Se connecter',
    hero_badge:'Plateforme d\'excellence · Bénin & Afrique',
    hero_t1:'Apprenez.',hero_t2:'Évoluez.',hero_t3:'Réussissez.',
    hero_sub:'Des formations professionnelles de qualité, accessibles depuis chez vous. Développez vos compétences avec des experts et propulsez votre carrière.',
    hero_cta1:'Voir les formations',hero_cta2:'En savoir plus',
    stat_students:'Étudiants',stat_courses:'Formations',stat_sat:'Satisfaction',
    feat_tag:'Pourquoi nous choisir',feat_title:'Une expérience <em>exceptionnelle</em>',
    courses_tag:'Catalogue',courses_title:'Nos <em>formations</em> phares',
    courses_sub:'Des formations conçues par des experts pour votre succès professionnel.',
    courses_all:'Voir toutes les formations',
    ai_tag:'Intelligence Artificielle',ai_title:'Votre tuteur <em>IA</em> personnel',
    ai_sub:'Notre assistant IA répond à vos questions 24h/24, explique les concepts complexes et vous accompagne à chaque étape.',
    about_tag:'Notre Histoire',about_title:'Bâtir l\'excellence <em>numérique</em> en Afrique',
    about_p1:'Luckily Academy est née d\'une conviction profonde : chaque Africain mérite d\'accéder à des formations de qualité internationale, dans sa langue, à des prix accessibles.',
    about_p2:'Fondée par Luc DEGUENON, spécialiste en technologie moderne, notre plateforme propose des formations pratiques et orientées résultats, conçues pour les réalités du marché africain et international.',
    testi_tag:'Témoignages',testi_title:'Ce que disent nos <em>étudiants</em>',
    cta_title:'Prêt à transformer votre avenir ?',
    cta_sub:'Rejoignez des milliers d\'étudiants qui ont choisi l\'excellence avec Luckily Academy.',
    cta_reg:'Créer mon compte',cta_browse:'Explorer les cours',
    access_title:'Accès à la formation',access_sub:'Entrez le code reçu après votre paiement',
    access_ph:'Code de la formation (ex: luckily2002)',
    access_btn:'Accéder au cours',access_err:'Code incorrect. Vérifiez votre code ou contactez-nous.',
    access_login:'Vous devez être connecté(e) pour accéder aux cours.',
    access_hint:'Ce code vous a été envoyé par WhatsApp après confirmation de votre paiement.',
    footer_copy:'© 2025 Luckily Academy. Tous droits réservés. Fondée par Luc DEGUENON.',
    ai_welcome:'Bonjour ! 👋 Je suis Luckily IA. Comment puis-je vous aider ?',
    ai_ph:'Posez votre question...',
  },
  en:{
    nav_home:'Home',nav_courses:'Courses',nav_about:'About',nav_contact:'Contact',nav_login:'Sign In',
    hero_badge:'Excellence Platform · Benin & Africa',
    hero_t1:'Learn.',hero_t2:'Grow.',hero_t3:'Succeed.',
    hero_sub:'High-quality professional training, accessible from home. Build your skills with experts and propel your career forward.',
    hero_cta1:'Explore Courses',hero_cta2:'Learn More',
    stat_students:'Students',stat_courses:'Courses',stat_sat:'Satisfaction',
    feat_tag:'Why Choose Us',feat_title:'An <em>exceptional</em> learning experience',
    courses_tag:'Catalog',courses_title:'Our flagship <em>courses</em>',
    courses_sub:'Courses designed by experts to propel you toward professional success.',
    courses_all:'View All Courses',
    ai_tag:'Artificial Intelligence',ai_title:'Your personal <em>AI</em> tutor',
    ai_sub:'Our AI assistant answers your questions 24/7, explains complex concepts and guides you every step of the way.',
    about_tag:'Our Story',about_title:'Building digital <em>excellence</em> in Africa',
    about_p1:'Luckily Academy was born from a deep conviction: every African deserves access to international-quality training, in their language, at accessible prices.',
    about_p2:'Founded by Luc DEGUENON, a modern technology specialist, our platform offers practical, results-oriented training.',
    testi_tag:'Testimonials',testi_title:'What our <em>students</em> say',
    cta_title:'Ready to transform your future?',
    cta_sub:'Join thousands of students who chose excellence with Luckily Academy.',
    cta_reg:'Create My Account',cta_browse:'Explore Courses',
    access_title:'Course Access',access_sub:'Enter the code received after your payment',
    access_ph:'Course code (e.g. luckily2002)',
    access_btn:'Access Course',access_err:'Incorrect code. Check your code or contact us.',
    access_login:'You must be logged in to access courses.',
    access_hint:'This code was sent to you via WhatsApp after payment confirmation.',
    footer_copy:'© 2025 Luckily Academy. All rights reserved. Founded by Luc DEGUENON.',
    ai_welcome:'Hello! 👋 I\'m Luckily AI. How can I help you?',
    ai_ph:'Ask your question...',
  },
  es:{
    nav_home:'Inicio',nav_courses:'Cursos',nav_about:'Sobre nosotros',nav_contact:'Contacto',nav_login:'Iniciar sesión',
    hero_badge:'Plataforma de excelencia · Benín & África',
    hero_t1:'Aprende.',hero_t2:'Evoluciona.',hero_t3:'Triunfa.',
    hero_sub:'Formación profesional de calidad, accesible desde casa. Desarrolla tus habilidades con expertos.',
    hero_cta1:'Ver cursos',hero_cta2:'Saber más',
    stat_students:'Estudiantes',stat_courses:'Cursos',stat_sat:'Satisfacción',
    feat_tag:'Por qué elegirnos',feat_title:'Una experiencia <em>excepcional</em>',
    courses_tag:'Catálogo',courses_title:'Nuestros <em>cursos</em> destacados',
    courses_sub:'Cursos diseñados por expertos para impulsar tu éxito profesional.',
    courses_all:'Ver todos los cursos',
    ai_tag:'Inteligencia Artificial',ai_title:'Tu tutor <em>IA</em> personal',
    ai_sub:'Nuestro asistente IA responde tus preguntas 24/7 y te guía en cada paso.',
    about_tag:'Nuestra Historia',about_title:'Construyendo la excelencia <em>digital</em> en África',
    about_p1:'Luckily Academy nació de una convicción profunda: cada africano merece formación de calidad internacional.',
    about_p2:'Fundada por Luc DEGUENON, especialista en tecnología moderna.',
    testi_tag:'Testimonios',testi_title:'Lo que dicen nuestros <em>estudiantes</em>',
    cta_title:'¿Listo para transformar tu futuro?',
    cta_sub:'Únete a miles de estudiantes que eligieron la excelencia con Luckily Academy.',
    cta_reg:'Crear mi cuenta',cta_browse:'Explorar cursos',
    access_title:'Acceso al curso',access_sub:'Ingresa el código recibido tras tu pago',
    access_ph:'Código del curso (ej: luckily2002)',
    access_btn:'Acceder al curso',access_err:'Código incorrecto. Verifica o contáctanos.',
    access_login:'Debes iniciar sesión para acceder a los cursos.',
    access_hint:'Este código fue enviado por WhatsApp tras confirmar tu pago.',
    footer_copy:'© 2025 Luckily Academy. Todos los derechos reservados. Fundada por Luc DEGUENON.',
    ai_welcome:'¡Hola! 👋 Soy Luckily IA. ¿Cómo puedo ayudarte?',
    ai_ph:'Haz tu pregunta...',
  },
  pt:{
    nav_home:'Início',nav_courses:'Cursos',nav_about:'Sobre nós',nav_contact:'Contato',nav_login:'Entrar',
    hero_badge:'Plataforma de excelência · Benim & África',
    hero_t1:'Aprenda.',hero_t2:'Evolua.',hero_t3:'Triunfe.',
    hero_sub:'Formação profissional de qualidade, acessível de casa. Desenvolva suas habilidades com especialistas.',
    hero_cta1:'Ver cursos',hero_cta2:'Saiba mais',
    stat_students:'Estudantes',stat_courses:'Cursos',stat_sat:'Satisfação',
    feat_tag:'Por que nos escolher',feat_title:'Uma experiência <em>excepcional</em>',
    courses_tag:'Catálogo',courses_title:'Nossos <em>cursos</em> destaque',
    courses_sub:'Cursos criados por especialistas para impulsionar seu sucesso profissional.',
    courses_all:'Ver todos os cursos',
    ai_tag:'Inteligência Artificial',ai_title:'Seu tutor <em>IA</em> pessoal',
    ai_sub:'Nosso assistente IA responde suas perguntas 24h e guia você em cada etapa.',
    about_tag:'Nossa História',about_title:'Construindo a excelência <em>digital</em> na África',
    about_p1:'Luckily Academy nasceu de uma convicção profunda: cada africano merece formação de qualidade internacional.',
    about_p2:'Fundada por Luc DEGUENON, especialista em tecnologia moderna.',
    testi_tag:'Depoimentos',testi_title:'O que dizem nossos <em>alunos</em>',
    cta_title:'Pronto para transformar seu futuro?',
    cta_sub:'Junte-se a milhares de alunos que escolheram a excelência com Luckily Academy.',
    cta_reg:'Criar minha conta',cta_browse:'Explorar cursos',
    access_title:'Acesso ao curso',access_sub:'Insira o código recebido após seu pagamento',
    access_ph:'Código do curso (ex: luckily2002)',
    access_btn:'Acessar o curso',access_err:'Código incorreto. Verifique ou entre em contato.',
    access_login:'Você precisa estar logado para acessar os cursos.',
    access_hint:'Este código foi enviado por WhatsApp após confirmação do pagamento.',
    footer_copy:'© 2025 Luckily Academy. Todos os direitos reservados. Fundada por Luc DEGUENON.',
    ai_welcome:'Olá! 👋 Sou a Luckily IA. Como posso ajudar?',
    ai_ph:'Faça sua pergunta...',
  }
};

function t(k){ return (T[currentLang]||{})[k] || (T.fr[k]) || k; }

function applyT(){
  document.querySelectorAll('[data-t]').forEach(el => {
    const v = t(el.dataset.t);
    if(v) el.innerHTML = v;
  });
  document.querySelectorAll('[data-t-ph]').forEach(el => {
    const v = t(el.dataset.tPh);
    if(v) el.placeholder = v;
  });
  const cl = document.getElementById('currentLang');
  if(cl) cl.textContent = currentLang.toUpperCase();
  document.documentElement.lang = currentLang;
}

function setLanguage(lang){
  currentLang = lang;
  localStorage.setItem('la_lang', lang);
  applyT();
  const dd = document.getElementById('langDrop');
  if(dd) dd.classList.remove('open');
  if(typeof renderCoursesPreview==='function') renderCoursesPreview();
  if(typeof renderCoursesPage==='function')    renderCoursesPage();
}

document.addEventListener('DOMContentLoaded', applyT);
