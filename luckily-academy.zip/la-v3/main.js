// ═══════════════════════════════════════════
// LUCKILY ACADEMY — main.js v3
// ═══════════════════════════════════════════
'use strict';

/* ── Thème immédiat (anti-flash) ── */
(function(){ document.documentElement.setAttribute('data-theme', localStorage.getItem('la_theme')||'light'); })();

/* ── Loader ── */
window.addEventListener('load',()=>{ setTimeout(()=>{ document.getElementById('loader')?.classList.add('hidden'); },1300); });

/* ── Dark Mode ── */
function updateThemeIcon(t){ const i=document.getElementById('themeIcon'); if(i) i.textContent=t==='dark'?'☀️':'🌙'; }
function toggleTheme(){
  const cur=document.documentElement.getAttribute('data-theme')||'light';
  const nxt=cur==='dark'?'light':'dark';
  document.documentElement.setAttribute('data-theme',nxt);
  localStorage.setItem('la_theme',nxt);
  updateThemeIcon(nxt);
  const dt=document.getElementById('darkToggle'); if(dt) dt.checked=nxt==='dark';
}

/* ── Navbar ── */
function initNavbar(){
  const nav=document.getElementById('navbar');
  const hbg=document.getElementById('hamburger');
  const nls=document.getElementById('navLinks');
  const thm=document.getElementById('themeBtn');
  const lbtn=document.getElementById('langBtn');
  const ldrop=document.getElementById('langDrop');

  if(nav){ const sc=()=>nav.classList.toggle('scrolled',window.scrollY>40); window.addEventListener('scroll',sc,{passive:true}); sc(); }
  if(hbg&&nls){
    hbg.addEventListener('click',e=>{ e.stopPropagation(); const o=nls.classList.toggle('open'); hbg.classList.toggle('open',o); });
    nls.querySelectorAll('.nav-link').forEach(l=>l.addEventListener('click',()=>{ nls.classList.remove('open'); hbg.classList.remove('open'); }));
    document.addEventListener('click',e=>{ if(nav&&!nav.contains(e.target)){ nls.classList.remove('open'); hbg.classList.remove('open'); } });
  }
  if(thm) thm.addEventListener('click',toggleTheme);
  if(lbtn&&ldrop){ lbtn.addEventListener('click',e=>{ e.stopPropagation(); ldrop.classList.toggle('open'); }); document.addEventListener('click',()=>ldrop.classList.remove('open')); }

  updateThemeIcon(document.documentElement.getAttribute('data-theme')||'light');

  const pg=(window.location.pathname.split('/').pop()||'index.html');
  document.querySelectorAll('.nav-link').forEach(l=>{
    const h=(l.getAttribute('href')||'').split('?')[0].split('#')[0];
    l.classList.toggle('active', h===pg||(pg===''&&h==='index.html'));
  });
}

/* ── Auth Nav ── */
function updateNavAuth(){
  const aBtn=document.getElementById('authNavBtn');
  const dBtn=document.getElementById('dashNavBtn');
  const aEl=document.getElementById('navAvatar');
  const s=(typeof getSession==='function')?getSession():null;
  if(s){ aBtn?.classList.add('hidden'); dBtn?.classList.remove('hidden'); if(aEl) aEl.textContent=(s.fullname||'U').charAt(0).toUpperCase(); }
  else { aBtn?.classList.remove('hidden'); dBtn?.classList.add('hidden'); }
}

/* ── Animations IntersectionObserver ── */
function initAnims(){
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('vis'); io.unobserve(e.target); } });
  },{threshold:.08,rootMargin:'0px 0px -40px 0px'});
  const watch=()=>document.querySelectorAll('.anim:not(.vis)').forEach(el=>io.observe(el));
  watch();
  new MutationObserver(watch).observe(document.body,{childList:true,subtree:true});
}

/* ── Compteurs ── */
function initCounters(){
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(e.isIntersecting&&!e.target.dataset.done){
        e.target.dataset.done='1';
        const target=parseInt(e.target.dataset.count,10);
        let cur=0; const step=target/112;
        const t=setInterval(()=>{ cur+=step; if(cur>=target){cur=target;clearInterval(t);} e.target.textContent=Math.floor(cur).toLocaleString('fr-FR'); },16);
      }
    });
  },{threshold:.6});
  document.querySelectorAll('[data-count]').forEach(el=>io.observe(el));
}

/* ── AI Modal ── */
function openAIModal(){ const m=document.getElementById('aiModal'); if(m){ m.classList.add('open'); setTimeout(()=>document.getElementById('aiInput')?.focus(),300); } }
function closeAIModal(){ document.getElementById('aiModal')?.classList.remove('open'); }

document.addEventListener('click',e=>{ const m=document.getElementById('aiModal'); if(m&&e.target===m) closeAIModal(); });
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ closeAIModal(); closePayModal(); } });

/* ── AI Chat ── */
const aiHist={modal:[],demo:[]};
let aiBusy={modal:false,demo:false};

async function callAI(msg,containerId){
  const key=containerId==='aiModalMsgs'?'modal':'demo';
  if(aiBusy[key]) return;
  aiBusy[key]=true;
  const box=document.getElementById(containerId);
  const tyEl=document.createElement('div'); tyEl.className='ai-msg bot';
  tyEl.innerHTML='<div class="msg-bbl ai-typing"><span></span><span></span><span></span></div>';
  box?.appendChild(tyEl); if(box) box.scrollTop=box.scrollHeight;
  aiHist[key].push({role:'user',content:msg});
  const lang=(typeof currentLang!=='undefined')?currentLang:'fr';
  const langLabel={'fr':'Français','en':'English','es':'Español','pt':'Português'}[lang]||'Français';
  try{
    const res=await fetch('https://api.anthropic.com/v1/messages',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        model:'claude-sonnet-4-20250514',max_tokens:800,
        system:`Tu es Luckily IA, assistant officiel de Luckily Academy — plateforme de formation en ligne fondée par Luc DEGUENON, Spécialiste en Technologie Moderne, basée à Cotonou, Bénin.\n\nFORMATIONS:\n• Web Marketing → 10 000 FCFA\n• Négociation Commerciale → 10 000 FCFA\n• Chargé Clientèle → 10 000 FCFA\n• Dev Frontend → 20 000 FCFA\n• Dev Backend → 25 000 FCFA\n• Analyse des Données → 15 000 FCFA\n• Word/Excel (Deb/Inter/Avancé) → 5 000 FCFA chacun\n• Outils Compatibilité → 5 000 FCFA\n\nPour s'inscrire : payer via WhatsApp +229 01 59 60 95 81 puis entrer le code reçu.\nEmail: cultech49@gmail.com\n\nRéponds en ${langLabel}, chaleureusement et de manière concise.`,
        messages:aiHist[key]
      })
    });
    const data=await res.json();
    const reply=data.content?.[0]?.text||(lang==='en'?"I'm here to help! Ask me anything.":"Je suis là pour vous aider !");
    aiHist[key].push({role:'assistant',content:reply});
    tyEl.parentNode?.removeChild(tyEl);
    appendMsg(reply,'bot',containerId);
  }catch{
    tyEl.parentNode?.removeChild(tyEl);
    appendMsg(lang==='en'?"Connection issue. Try again.":"Problème de connexion. Réessayez.",'bot',containerId);
  }finally{ aiBusy[key]=false; }
}

function appendMsg(text,type,cId){
  const c=document.getElementById(cId); if(!c) return;
  const d=document.createElement('div'); d.className='ai-msg '+type;
  d.innerHTML=`<div class="msg-bbl">${text.replace(/\n/g,'<br>')}</div>`;
  c.appendChild(d); c.scrollTop=c.scrollHeight;
}

async function sendAIModal(){ const i=document.getElementById('aiInput'); if(!i||!i.value.trim()||aiBusy.modal) return; const m=i.value.trim(); i.value=''; appendMsg(m,'user','aiModalMsgs'); await callAI(m,'aiModalMsgs'); }
async function sendAIDemo(){  const i=document.getElementById('aiDemoInput'); if(!i||!i.value.trim()||aiBusy.demo) return; const m=i.value.trim(); i.value=''; appendMsg(m,'user','aiDemoMsgs'); await callAI(m,'aiDemoMsgs'); }

/* ══════════════════════════════════════════
   PAIEMENT → WHATSAPP
══════════════════════════════════════════ */
const WA='2290159609581';

function showPaymentModal(courseId,userId){
  const c=(typeof getCourseById==='function')?getCourseById(courseId):null;
  if(!c) return;
  closePayModal();
  const m=document.createElement('div');
  m.id='payModal'; m.className='modal-ov open';
  m.innerHTML=`
    <div class="pay-box" id="payBox">
      <div class="pay-head">
        <div class="pay-title"><span>💳</span><span>Finaliser l'inscription</span></div>
        <button class="pay-close-btn" onclick="closePayModal()">✕</button>
      </div>
      <div style="padding:22px 22px 0;">
        <!-- Récap -->
        <div style="background:var(--bg-alt);border-radius:14px;padding:14px;display:flex;align-items:center;gap:12px;margin-bottom:20px;border:1px solid var(--border);">
          <span style="font-size:2rem;flex-shrink:0;">${c.icon}</span>
          <div style="flex:1;min-width:0;">
            <div style="font-family:var(--ff-d);font-weight:700;font-size:1rem;margin-bottom:2px;">${c.title}</div>
            <div style="font-size:.74rem;color:var(--text-m);">${c.category} · ${c.duration}</div>
          </div>
          <div style="text-align:right;flex-shrink:0;">
            <div style="font-family:var(--ff-d);font-size:1.3rem;font-weight:800;color:var(--primary);">${(typeof formatPrice==='function')?formatPrice(c.price):c.price+' FCFA'}</div>
            <div style="font-size:.68rem;color:var(--text-m);">Accès à vie</div>
          </div>
        </div>
        <!-- Modes de paiement -->
        <div style="margin-bottom:18px;">
          <div style="font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-m);margin-bottom:10px;">Mode de paiement</div>
          <div style="display:flex;flex-direction:column;gap:8px;">
            <label id="lbl_mtn" class="pay-method-lbl active"><input type="radio" name="pm" value="mtn" checked onchange="hlPay()" style="accent-color:var(--primary);width:14px;height:14px;"/> <span style="font-size:1.1rem;">📱</span> <div><div style="font-weight:600;font-size:.86rem;">MTN Mobile Money</div><div style="font-size:.72rem;color:var(--text-m);">MoMo instantané</div></div></label>
            <label id="lbl_moov" class="pay-method-lbl"><input type="radio" name="pm" value="moov" onchange="hlPay()" style="accent-color:var(--primary);width:14px;height:14px;"/> <span style="font-size:1.1rem;">🔵</span> <div><div style="font-weight:600;font-size:.86rem;">Moov Money (Flooz)</div><div style="font-size:.72rem;color:var(--text-m);">Paiement Flooz</div></div></label>
            <label id="lbl_wave" class="pay-method-lbl"><input type="radio" name="pm" value="wave" onchange="hlPay()" style="accent-color:var(--primary);width:14px;height:14px;"/> <span style="font-size:1.1rem;">🌊</span> <div><div style="font-weight:600;font-size:.86rem;">Wave</div><div style="font-size:.72rem;color:var(--text-m);">Paiement Wave</div></div></label>
            <label id="lbl_carte" class="pay-method-lbl"><input type="radio" name="pm" value="carte" onchange="hlPay()" style="accent-color:var(--primary);width:14px;height:14px;"/> <span style="font-size:1.1rem;">💳</span> <div><div style="font-weight:600;font-size:.86rem;">Carte Visa / Mastercard</div><div style="font-size:.72rem;color:var(--text-m);">Carte bancaire</div></div></label>
          </div>
        </div>
        <!-- Téléphone -->
        <div style="margin-bottom:14px;">
          <div style="font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-m);margin-bottom:7px;">Téléphone <span style="color:#EF233C;">*</span></div>
          <input type="tel" id="payPhone" class="pay-inp" placeholder="+229 01 XX XX XX XX" />
        </div>
        <!-- Nom si non connecté -->
        ${!(typeof getSession==='function'&&getSession())?`
        <div style="margin-bottom:14px;">
          <div style="font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-m);margin-bottom:7px;">Nom complet <span style="color:#EF233C;">*</span></div>
          <input type="text" id="payName" class="pay-inp" placeholder="Prénom Nom" />
        </div>
        <div style="margin-bottom:14px;">
          <div style="font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-m);margin-bottom:7px;">Email</div>
          <input type="email" id="payEmail" class="pay-inp" placeholder="votre@email.com" />
        </div>`:''}
      </div>
      <div style="padding:16px 22px 22px;">
        <button class="btn-wa-pay" onclick="goWhatsApp('${courseId}')">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          Continuer vers WhatsApp
        </button>
        <p style="text-align:center;font-size:.72rem;color:var(--text-m);margin-top:10px;line-height:1.5;">🔒 Paiement confirmé manuellement. Accès activé dans les <strong>5 minutes</strong>.</p>
      </div>
    </div>`;
  document.body.appendChild(m);
  document.body.style.overflow='hidden';
  m.addEventListener('click',e=>{ if(e.target===m) closePayModal(); });
}

function hlPay(){
  const sel=document.querySelector('input[name="pm"]:checked')?.value;
  ['mtn','moov','wave','carte'].forEach(k=>{
    const l=document.getElementById('lbl_'+k);
    if(l){ l.classList.toggle('active',k===sel); }
  });
}

function closePayModal(){
  const m=document.getElementById('payModal');
  if(m){ m.remove(); document.body.style.overflow=''; }
}

function goWhatsApp(courseId){
  const c=(typeof getCourseById==='function')?getCourseById(courseId):null;
  if(!c) return;
  const session=(typeof getSession==='function')?getSession():null;
  const user=(typeof getCurrentUser==='function')?getCurrentUser():null;
  const method=document.querySelector('input[name="pm"]:checked')?.value||'mtn';
  const phone=document.getElementById('payPhone')?.value?.trim()||'';
  const nameI=document.getElementById('payName');
  const emailI=document.getElementById('payEmail');
  const nom=nameI?(nameI.value.trim()||''):(user?.fullname||session?.fullname||'');
  const email=emailI?(emailI.value.trim()||''):(user?.email||session?.email||'');

  if(!phone){ const pi=document.getElementById('payPhone'); if(pi){pi.style.borderColor='#EF233C';pi.focus();} showToast('⚠ Renseignez votre téléphone.','error'); return; }
  if(!session&&!nom){ const ni=document.getElementById('payName'); if(ni){ni.style.borderColor='#EF233C';ni.focus();} showToast('⚠ Renseignez votre nom.','error'); return; }

  const ml={'mtn':'MTN Mobile Money','moov':'Moov Money (Flooz)','wave':'Wave','carte':'Carte Visa/Mastercard'};
  const ref='LA-'+Date.now().toString(36).toUpperCase();
  const price=(typeof formatPrice==='function')?formatPrice(c.price):c.price+' FCFA';
  const date=new Date().toLocaleString('fr-FR',{dateStyle:'full',timeStyle:'short'});

  const msg=`🎓 *LUCKILY ACADEMY — Demande de paiement*\n\nBonjour, je souhaite m'inscrire à la formation :\n\n📚 *Formation :* ${c.title}\n⏱ *Durée :* ${c.duration}\n💰 *Montant :* ${price}\n\n────────────────────\n👤 *Mes informations :*\n• Nom : ${nom||'Non renseigné'}\n• Email : ${email||'Non renseigné'}\n• Téléphone : ${phone}\n\n💳 *Mode de paiement :* ${ml[method]||method}\n📅 *Date :* ${date}\n🔖 *Référence :* ${ref}\n────────────────────\n\nMerci de me confirmer les instructions de paiement pour finaliser mon inscription ! 🙏`;

  window.open('https://wa.me/'+WA+'?text='+encodeURIComponent(msg),'_blank','noopener');

  const box=document.getElementById('payBox');
  if(box) box.innerHTML=`
    <div style="padding:44px 28px;text-align:center;">
      <div style="font-size:3.5rem;margin-bottom:16px;animation:successBounce .5s ease both;">✅</div>
      <h2 style="font-family:var(--ff-d);font-size:1.6rem;font-weight:700;margin-bottom:10px;color:var(--text);">WhatsApp ouvert !</h2>
      <p style="color:var(--text-m);font-size:.88rem;margin-bottom:8px;">Votre demande a été préparée avec toutes vos informations.</p>
      <div style="background:var(--bg-alt);border-radius:10px;padding:10px 16px;margin:14px auto;display:inline-block;">
        <div style="font-size:.7rem;color:var(--text-m);">Référence</div>
        <div style="font-family:var(--ff-d);font-size:1.2rem;font-weight:800;color:var(--primary);letter-spacing:.05em;">${ref}</div>
      </div>
      <p style="color:var(--text-m);font-size:.83rem;margin-bottom:24px;">Notre équipe vous confirme les instructions et active votre accès <strong>dans les 5 minutes</strong>.</p>
      <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
        <a href="https://wa.me/${WA}?text=${encodeURIComponent(msg)}" target="_blank" style="padding:10px 22px;border-radius:50px;background:linear-gradient(135deg,#25D366,#128C7E);color:#fff;font-weight:700;font-size:.83rem;text-decoration:none;">💬 Ré-ouvrir WhatsApp</a>
        <button onclick="closePayModal()" style="padding:10px 22px;border-radius:50px;border:1.5px solid var(--border);color:var(--text-m);font-size:.83rem;cursor:pointer;background:transparent;">Fermer</button>
      </div>
    </div>`;
}

/* ── Settings ── */
function initSettings(){
  const dt=document.getElementById('darkToggle');
  if(dt){ dt.checked=document.documentElement.getAttribute('data-theme')==='dark'; dt.addEventListener('change',toggleTheme); }
  const nt=document.getElementById('notifToggle');
  if(nt){ nt.checked=localStorage.getItem('la_notif')!=='false'; nt.addEventListener('change',e=>localStorage.setItem('la_notif',e.target.checked)); }
  const ls=document.getElementById('langSelect');
  if(ls){ ls.value=(typeof currentLang!=='undefined')?currentLang:'fr'; ls.addEventListener('change',e=>{ if(typeof setLanguage==='function') setLanguage(e.target.value); }); }
  const pf=document.getElementById('profileForm');
  if(pf){
    const user=(typeof getCurrentUser==='function')?getCurrentUser():null;
    if(user){
      const pn=document.getElementById('profName'); if(pn) pn.value=user.fullname||'';
      const pe=document.getElementById('profEmail'); if(pe) pe.value=user.email||'';
      const pp=document.getElementById('profPhone'); if(pp) pp.value=user.phone||'';
      const sA=document.getElementById('sbAvatar'); if(sA) sA.textContent=user.fullname.charAt(0).toUpperCase();
      const sN=document.getElementById('sbName'); if(sN) sN.textContent=user.fullname;
      const sE=document.getElementById('sbEmail'); if(sE) sE.textContent=user.email;
    }
    pf.addEventListener('submit',e=>{
      e.preventDefault();
      const s=(typeof getSession==='function')?getSession():null; if(!s) return;
      const users=(typeof getUsers==='function')?getUsers():[];
      const idx=users.findIndex(u=>u.id===s.userId);
      if(idx!==-1){
        users[idx].fullname=document.getElementById('profName')?.value||users[idx].fullname;
        users[idx].phone=document.getElementById('profPhone')?.value||'';
        if(typeof saveUsers==='function') saveUsers(users);
        showToast('✓ Profil mis à jour !','success');
      }
    });
  }
  const lb=document.getElementById('logoutBtn');
  if(lb) lb.addEventListener('click',()=>{ if(typeof logout==='function') logout(); });
}

/* ── Toast ── */
function showToast(msg,type='info'){
  document.querySelector('.la-toast')?.remove();
  const c={success:'#06D6A0',error:'#EF233C',info:'#00B4D8',warning:'#F77F00'};
  const t=document.createElement('div'); t.className='la-toast';
  t.textContent=msg;
  t.style.cssText=`background:${c[type]||c.info};`;
  document.body.appendChild(t);
  requestAnimationFrame(()=>{ t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)'; });
  setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(14px)'; setTimeout(()=>t.remove(),350); },3200);
}

/* ── Smooth scroll ── */
document.addEventListener('click',e=>{
  const a=e.target.closest('a[href^="#"]');
  if(!a) return;
  const h=a.getAttribute('href');
  if(!h||h==='#') return;
  const el=document.querySelector(h);
  if(el){ e.preventDefault(); el.scrollIntoView({behavior:'smooth',block:'start'}); }
});

/* ── CSS runtime ── */
const rs=document.createElement('style');
rs.textContent=`
  @keyframes successBounce{0%{transform:scale(0) rotate(-10deg)}60%{transform:scale(1.2) rotate(3deg)}100%{transform:scale(1) rotate(0)}}
  @keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}
  .la-toast{opacity:0;transform:translateX(-50%) translateY(14px);transition:all .3s cubic-bezier(.34,1.56,.64,1);}
  .hidden{display:none!important;}
`;
document.head.appendChild(rs);

/* ── INIT ── */
document.addEventListener('DOMContentLoaded',()=>{
  initNavbar();
  updateNavAuth();
  initAnims();
  initCounters();

  const pg=(window.location.pathname.split('/').pop()||'index.html').replace(/\.html$/,'');
  if(pg==='index'||pg==='')        { if(typeof renderCoursesPreview==='function') renderCoursesPreview(); }
  if(pg==='courses')               { if(typeof renderCoursesPage==='function')    renderCoursesPage(); }
  if(pg==='course-detail')         { if(typeof renderCourseDetail==='function')   renderCourseDetail(); }
  if(pg==='lesson')                { if(typeof renderLesson==='function')         renderLesson(); }
  if(pg==='dashboard')             { if(typeof renderDashboard==='function')      renderDashboard(); }
  if(pg==='profile')               { initSettings(); }
});
