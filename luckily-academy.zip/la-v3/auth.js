// ═══════════════════════════════════════════
// LUCKILY ACADEMY — auth.js
// Gestion : comptes, sessions, inscriptions,
//           codes d'accès par formation
// ═══════════════════════════════════════════
'use strict';

const K_USERS  = 'la_users';
const K_SESS   = 'la_session';
const K_ENROLL = 'la_enroll';
const K_PROG   = 'la_progress';

// ── Codes d'accès par formation (mot de passe donné après paiement)
// Format :  courseId → code
const COURSE_CODES = {
  'web-marketing':          'luckily2002',
  'negociation-commerciale':'luckily2003',
  'charge-clientele':       'luckily2004',
  'dev-frontend':           'luckily2005',
  'dev-backend':            'luckily2006',
  'analyse-donnees':        'luckily2007',
  'word-debutant':          'luckily2008',
  'word-intermediaire':     'luckily2009',
  'word-avance':            'luckily2010',
  'excel-debutant':         'luckily2011',
  'excel-intermediaire':    'luckily2012',
  'excel-avance':           'luckily2013',
  'outils-compatibilite':   'luckily2014',
};

// ── Utilitaires localStorage ──
function _get(k)    { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } }
function _set(k, v) { localStorage.setItem(k, JSON.stringify(v)); }

// ── Utilisateurs ──
function getUsers()       { return _get(K_USERS) || []; }
function saveUsers(users) { _set(K_USERS, users); }

function registerUser({ fullname, email, password, phone }) {
  const users = getUsers();
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    return { success: false, message: 'Cet email est déjà utilisé.' };
  }
  const user = {
    id: 'u_' + Date.now(),
    fullname: fullname.trim(),
    email: email.toLowerCase().trim(),
    password: btoa(unescape(encodeURIComponent(password))),
    phone: phone || '',
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  saveUsers(users);
  return { success: true, user };
}

function loginUser(email, password) {
  const users = getUsers();
  const enc   = btoa(unescape(encodeURIComponent(password)));
  const user  = users.find(u => u.email.toLowerCase() === email.toLowerCase().trim() && u.password === enc);
  if (!user) return { success: false, message: 'Email ou mot de passe incorrect.' };
  return { success: true, user };
}

// ── Session ──
function setSession(user) { _set(K_SESS, { userId: user.id, email: user.email, fullname: user.fullname }); }
function getSession()     { return _get(K_SESS); }
function clearSession()   { localStorage.removeItem(K_SESS); }
function isLoggedIn()     { return !!getSession(); }
function getCurrentUser() {
  const s = getSession();
  if (!s) return null;
  return getUsers().find(u => u.id === s.userId) || null;
}

// ── Inscriptions ──
function getEnrollments()      { return _get(K_ENROLL) || {}; }
function setEnrollments(data)  { _set(K_ENROLL, data); }

function isEnrolled(userId, courseId) {
  const e = getEnrollments();
  return !!(e[userId] && e[userId].includes(courseId));
}
function enrollUser(userId, courseId) {
  const e = getEnrollments();
  if (!e[userId]) e[userId] = [];
  if (!e[userId].includes(courseId)) e[userId].push(courseId);
  setEnrollments(e);
}
function getUserCourses(userId) {
  return (getEnrollments()[userId] || []);
}

// ── Code d'accès ──
function verifyCourseCode(courseId, inputCode) {
  const expected = COURSE_CODES[courseId];
  if (!expected) return false;
  return inputCode.trim().toLowerCase() === expected.toLowerCase();
}

// ── Progression ──
function getProgress()    { return _get(K_PROG) || {}; }
function saveProgress(p)  { _set(K_PROG, p); }

function markLessonComplete(userId, courseId, lessonId) {
  const p   = getProgress();
  const key = userId + '_' + courseId;
  if (!p[key]) p[key] = [];
  if (!p[key].includes(lessonId)) p[key].push(lessonId);
  saveProgress(p);
}
function getLessonProgress(userId, courseId) {
  return (getProgress()[userId + '_' + courseId] || []);
}
function getCourseProgressPct(userId, courseId, total) {
  if (!total) return 0;
  return Math.round((getLessonProgress(userId, courseId).length / total) * 100);
}

// ── Nav auth state ──
function updateNavAuth() {
  const authBtn  = document.getElementById('authNavBtn');
  const dashBtn  = document.getElementById('dashNavBtn');
  const avatarEl = document.getElementById('navAvatar');
  const s        = getSession();
  if (s) {
    authBtn  && authBtn.classList.add('hidden');
    dashBtn  && dashBtn.classList.remove('hidden');
    avatarEl && (avatarEl.textContent = (s.fullname || 'U').charAt(0).toUpperCase());
  } else {
    authBtn  && authBtn.classList.remove('hidden');
    dashBtn  && dashBtn.classList.add('hidden');
  }
}

function logout() {
  clearSession();
  window.location.href = 'index.html';
}

document.addEventListener('DOMContentLoaded', updateNavAuth);
