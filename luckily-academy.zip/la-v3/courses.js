// ═══════════════════════════════════════════
// LUCKILY ACADEMY — courses.js v3
// Contenu complet de toutes les formations
// ═══════════════════════════════════════════
'use strict';

/* ════════ DONNÉES FORMATIONS ════════ */
const COURSES_DATA = [
  {
    id:'web-marketing', title:'Web Marketing', price:10000, currency:'FCFA',
    category:'Marketing', level:'Débutant → Pro', duration:'8 semaines',
    icon:'📢', color:'#00B4D8',
    img:'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=700&q=80',
    description:'Maîtrisez les stratégies digitales : SEO, réseaux sociaux, publicité en ligne, email marketing et analytics pour développer votre activité.',
    summary:['Introduction au marketing digital','Stratégie de contenu et branding','SEO et référencement naturel','Réseaux sociaux et community management','Google Ads et Facebook Ads','Email marketing et automation','Analytics et mesure des performances','Créer son plan marketing complet'],
    chapters:[
      {id:1,title:'Introduction au Marketing Digital',lessons:[
        {id:1,title:'Qu\'est-ce que le Marketing Digital ?',image:'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=800&q=80',
         content:`Le marketing digital est l'ensemble des actions et stratégies marketing réalisées sur les canaux numériques : sites web, moteurs de recherche, réseaux sociaux, emails et applications mobiles.\n\nContrairement au marketing traditionnel (télévision, radio, presse), le marketing digital permet de cibler précisément votre audience, de mesurer vos résultats en temps réel et d'ajuster vos campagnes instantanément.\n\nLes piliers du marketing digital sont :\n• Le SEO (référencement naturel)\n• Le SEA (publicité payante)\n• Les réseaux sociaux\n• L'email marketing\n• Le content marketing\n• L'analytics`},
        {id:2,title:'L\'écosystème digital africain',image:'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&q=80',
         content:`L'Afrique connaît une révolution digitale sans précédent. Avec plus de 600 millions d'utilisateurs internet et une pénétration mobile de 80%, le continent offre des opportunités immenses pour les marketeurs digitaux.\n\nAu Bénin et en Afrique de l'Ouest, les plateformes les plus utilisées sont :\n• WhatsApp (90% des internautes)\n• Facebook (70%)\n• Instagram (45%)\n• TikTok (croissance de 200% par an)\n\nComprendre ces spécificités locales est indispensable pour créer des campagnes efficaces sur le marché africain.`},
        {id:3,title:'Définir ses objectifs SMART',image:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
         content:`Avant toute action marketing, définissez des objectifs SMART :\n\n• Spécifiques : "Obtenir 500 abonnés Facebook en 3 mois"\n• Mesurables : vous pouvez compter les abonnés\n• Atteignables : réaliste selon vos ressources\n• Réalistes : cohérent avec votre marché\n• Temporels : avec une date limite claire\n\nExemple d'objectif mal défini : "Augmenter ma visibilité sur les réseaux sociaux"\n\nExemple d'objectif SMART : "Générer 200 leads qualifiés via Facebook Ads en 60 jours avec un budget de 150.000 FCFA"`},
      ]},
      {id:2,title:'SEO — Référencement Naturel',lessons:[
        {id:4,title:'Les bases du SEO',image:'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?w=800&q=80',
         content:`Le SEO (Search Engine Optimization) est l'art d'optimiser votre site web pour apparaître en première page de Google sans payer.\n\n**Pourquoi le SEO est crucial :**\n• 75% des utilisateurs ne vont jamais au-delà de la première page\n• Les résultats organiques reçoivent 10x plus de clics que les publicités payantes\n• Le SEO génère des résultats durables\n\n**Les 3 piliers du SEO :**\n1. Le SEO technique (vitesse, mobile-friendly, structure)\n2. Le SEO on-page (mots-clés, contenu, balises)\n3. Le SEO off-page (backlinks, réputation)`},
        {id:5,title:'Recherche de mots-clés',image:'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80',
         content:`La recherche de mots-clés est la base de toute stratégie SEO réussie. Elle consiste à identifier les termes que votre audience cible tape dans Google.\n\n**Outils gratuits :**\n• Google Keyword Planner\n• Google Search Console\n• Ubersuggest (version gratuite)\n• Answer The Public\n\n**Types de mots-clés :**\n• Mots-clés génériques (forte concurrence, gros volume)\n• Mots-clés de longue traîne (moins de concurrence, plus de conversions)\n\nExemple : "formation marketing" (générique) vs "formation web marketing débutant Bénin" (longue traîne)`},
      ]},
      {id:3,title:'Réseaux Sociaux & Community Management',lessons:[
        {id:6,title:'Stratégie Facebook & Instagram',image:'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&q=80',
         content:`Facebook et Instagram sont les deux plateformes dominantes en Afrique de l'Ouest. Voici comment les maîtriser :\n\n**Facebook :**\n• Créez une Page Business professionnelle\n• Publiez 3 à 5 fois par semaine\n• Utilisez Facebook Groups pour créer une communauté\n• Format optimaux : vidéos courtes (30-90s), images de qualité\n\n**Instagram :**\n• Cohérence visuelle (couleurs, style)\n• Stories quotidiennes (engagement x3)\n• Reels pour atteindre de nouveaux abonnés\n• Hashtags pertinents (10-15 par post)`},
        {id:7,title:'Créer du contenu viral',image:'https://images.unsplash.com/photo-1533750349088-cd871a92f312?w=800&q=80',
         content:`Un contenu viral est un contenu qui se partage spontanément. Il existe des formules éprouvées :\n\n**Les 5 types de contenu qui fonctionnent :**\n1. Éducatif : "5 erreurs à éviter en SEO"\n2. Inspirant : success stories, témoignages\n3. Divertissant : humour, challenges\n4. Utile : tutoriels, guides pratiques\n5. Émotionnel : histoires touchantes\n\n**La règle 80/20 :**\n80% de contenu à valeur ajoutée pour votre audience\n20% de contenu promotionnel\n\nPostez aux heures de pointe : 12h-14h et 18h-21h (heure locale)`},
      ]},
      {id:4,title:'Publicité en Ligne (Ads)',lessons:[
        {id:8,title:'Facebook Ads — Guide complet',image:'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&q=80',
         content:`Facebook Ads est la plateforme publicitaire la plus puissante pour toucher les Africains en ligne.\n\n**Structure d'une campagne :**\n1. Campagne → Objectif (trafic, leads, ventes)\n2. Groupe d'annonces → Audience + budget\n3. Annonce → Visuel + texte\n\n**Ciblage avancé :**\n• Par pays, ville, langue\n• Par âge, sexe, situation familiale\n• Par centres d'intérêt (business, mode, sport...)\n• Audiences similaires (Lookalike)\n\n**Budget recommandé pour débuter :**\n• Test : 2.000 - 5.000 FCFA/jour\n• Campagne réelle : 10.000 - 50.000 FCFA/jour`},
        {id:9,title:'Email Marketing & Automation',image:'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=800&q=80',
         content:`L'email marketing reste le canal avec le meilleur ROI : 42$ de retour pour chaque dollar investi.\n\n**Pour commencer :**\n1. Choisissez un outil : Mailchimp (gratuit jusqu'à 500 contacts), Brevo, ActiveCampaign\n2. Créez une liste de contacts\n3. Rédigez vos emails\n4. Automatisez vos séquences\n\n**Séquence de bienvenue (5 emails) :**\n• J1 : Email de bienvenue + cadeau\n• J3 : Votre histoire / valeurs\n• J5 : Contenu éducatif\n• J7 : Témoignages clients\n• J10 : Offre commerciale\n\n**Taux d'ouverture moyens :**\nSecteur éducation : 28-35%`},
      ]},
    ]
  },
  {
    id:'negociation-commerciale', title:'Négociation Commerciale', price:10000, currency:'FCFA',
    category:'Business', level:'Débutant → Avancé', duration:'6 semaines',
    icon:'🤝', color:'#F77F00',
    img:'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=700&q=80',
    description:'Développez vos compétences de négociateur : techniques de persuasion, gestion des objections, closing et fidélisation client.',
    summary:['Psychologie de la négociation','Préparation et stratégie','Techniques de persuasion (Cialdini)','Gestion des objections','L\'art du closing','Négociation interculturelle africaine','Fidélisation et suivi client','Mise en pratique et jeux de rôle'],
    chapters:[
      {id:1,title:'Psychologie & Fondamentaux',lessons:[
        {id:1,title:'Psychologie de la négociation',image:'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=800&q=80',
         content:`La négociation est avant tout une affaire de psychologie. Comprendre comment fonctionne l'esprit humain vous donnera un avantage décisif.\n\n**Les biais cognitifs utiles :**\n• Biais de réciprocité : donnez avant de demander\n• Effet d'ancrage : le premier chiffre prononcé influence tout\n• Aversion à la perte : "vous risquez de perdre X" est plus puissant que "vous gagnez X"\n\n**Les 4 styles de négociateur :**\n1. Compétitif (gagnant/perdant)\n2. Collaboratif (gagnant/gagnant) ← recommandé\n3. Accommodant (perdant/gagnant)\n4. Évitant (perdant/perdant)`},
        {id:2,title:'Préparer sa négociation',image:'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&q=80',
         content:`80% du succès d'une négociation se joue avant la négociation elle-même.\n\n**La méthode BATNA :**\nBATNA = Best Alternative To a Negotiated Agreement\n(Meilleure alternative à un accord négocié)\n\nConnaissez votre BATNA et celui de votre interlocuteur. Plus votre BATNA est solide, plus vous négociez avec confiance.\n\n**Checklist de préparation :**\n☑ Quel est mon objectif idéal ?\n☑ Quel est mon seuil minimal acceptable ?\n☑ Quels sont les besoins réels de mon interlocuteur ?\n☑ Quelles sont mes concessions possibles ?\n☑ Quels sont mes arguments clés ?`},
      ]},
      {id:2,title:'Techniques de Persuasion',lessons:[
        {id:3,title:'Les 6 principes de Cialdini',image:'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&q=80',
         content:`Robert Cialdini a identifié 6 principes universels de persuasion :\n\n1. **Réciprocité** : Les gens rendent ce qu'ils reçoivent\n→ Offrez quelque chose avant de demander\n\n2. **Engagement & Cohérence** : On reste fidèle à ses engagements\n→ Faites dire "oui" sur des petites choses d'abord\n\n3. **Preuve sociale** : On fait comme les autres\n→ Utilisez des témoignages et chiffres clients\n\n4. **Autorité** : On fait confiance aux experts\n→ Montrez vos certifications, expériences\n\n5. **Sympathie** : On dit oui à ceux qu'on aime\n→ Créez un lien avant de vendre\n\n6. **Rareté** : Ce qui est rare est désirable\n→ "Places limitées", "Offre valable jusqu'au..."`},
        {id:4,title:'Gérer les objections',image:'https://images.unsplash.com/photo-1573497019418-b400bb3ab074?w=800&q=80',
         content:`Une objection n'est pas un refus. C'est une demande d'information supplémentaire.\n\n**Les 5 objections les plus courantes :**\n\n1. "C'est trop cher" → "Par rapport à quoi ? Quel budget avez-vous ?\"\n2. "Je dois réfléchir" → "Qu'est-ce qui vous retient ?\"\n3. "Je n'ai pas le temps" → "Combien de temps vous faudrait-il ?\"\n4. "Je dois en parler à..." → "Quand pouvez-vous lui en parler ?\"\n5. "J'ai déjà un fournisseur" → "Qu'est-ce qui vous rendrait curieux d'en découvrir un autre ?\"\n\n**Méthode ACRE :**\n- A : Accepter (écouter sans interrompre)\n- C : Clarifier (poser des questions)\n- R : Répondre (apporter une solution)\n- E : Engager (avancer vers la décision)`},
      ]},
      {id:3,title:'Closing & Fidélisation',lessons:[
        {id:5,title:'L\'art du closing',image:'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&q=80',
         content:`Le closing est le moment de conclure la vente. Beaucoup de commerciaux échouent ici par peur du refus.\n\n**Techniques de closing efficaces :**\n\n1. **La question alternative** : "Vous préférez commencer lundi ou mardi ?"\n2. **Le résumé** : "Donc si je comprends bien, vous avez besoin de X, Y et Z. Mon offre couvre tout cela. On y va ?"\n3. **L'urgence** : "Je n'ai plus que 2 places disponibles ce mois-ci"\n4. **L'essai** : "Commençons par une période d'essai de 30 jours"\n\n**Signaux d'achat à repérer :**\n• Questions sur les délais de livraison\n• Questions sur la garantie\n• Demande de références clients\n• Calculs du ROI`},
      ]},
    ]
  },
  {
    id:'charge-clientele', title:'Chargé Clientèle', price:10000, currency:'FCFA',
    category:'Service', level:'Débutant → Pro', duration:'6 semaines',
    icon:'🎯', color:'#7209B7',
    img:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=700&q=80',
    description:'Excellez dans la relation client : accueil, gestion des réclamations, fidélisation et service après-vente de qualité professionnelle.',
    summary:['L\'excellence dans l\'accueil client','Communication verbale et non-verbale','Gestion des réclamations','Fidélisation et satisfaction client','Outils CRM et suivi client','Gestion du stress et des conflits','Service client multicanal','KPIs et mesure de la satisfaction'],
    chapters:[
      {id:1,title:'Excellence dans l\'Accueil',lessons:[
        {id:1,title:'L\'art de l\'accueil professionnel',image:'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80',
         content:`L'accueil est le premier contact entre le client et votre entreprise. Il conditionne toute la relation future.\n\n**Les 7 secondes fatidiques :**\nLes études montrent que le client forge son impression en 7 secondes. Pendant ces 7 secondes, il évalue :\n• Votre apparence (55%)\n• Votre ton de voix (38%)\n• Vos mots (7%)\n\n**Le SBAM :**\n• Sourire\n• Bonjour\n• Au revoir\n• Merci\n\nCes 4 éléments simples peuvent transformer une interaction ordinaire en expérience mémorable.`},
        {id:2,title:'Communication empathique',image:'https://images.unsplash.com/photo-1573497620053-ea5300f94f21?w=800&q=80',
         content:`L'empathie est la capacité à se mettre à la place du client pour le comprendre véritablement.\n\n**L'écoute active en 5 étapes :**\n1. Regardez votre interlocuteur (contact visuel)\n2. Ne l'interrompez pas\n3. Reformulez : "Si je comprends bien, vous dites que..."\n4. Posez des questions ouvertes\n5. Validez ses émotions : "Je comprends que cela soit frustrant"\n\n**Les mots à éviter :**\n✗ "Ce n'est pas mon problème"\n✗ "Calmez-vous"\n✗ "Ce n'est pas possible"\n✗ "Vous auriez dû..."\n\n**Les mots à utiliser :**\n✓ "Je comprends votre situation"\n✓ "Voici ce que je vais faire pour vous"\n✓ "Donnez-moi un instant, je cherche la meilleure solution"`},
      ]},
      {id:2,title:'Gestion des Réclamations',lessons:[
        {id:3,title:'Transformer un mécontentement en fidélité',image:'https://images.unsplash.com/photo-1573497019418-b400bb3ab074?w=800&q=80',
         content:`Un client qui se plaint est une opportunité en or. 96% des clients insatisfaits ne se plaignent jamais — ils partent silencieusement.\n\n**La méthode HEARD :**\n• H - Hear (Écoutez sans interrompre)\n• E - Empathize (Exprimez votre empathie)\n• A - Apologize (Excusez-vous sincèrement)\n• R - Resolve (Proposez une solution)\n• D - Diagnose (Analysez pour éviter la récidive)\n\n**Statistique clé :**\nUn client dont la réclamation a été bien traitée est 7 fois plus fidèle qu'un client n'ayant jamais eu de problème.`},
      ]},
    ]
  },
  {
    id:'dev-frontend', title:'Développement Web Frontend', price:20000, currency:'FCFA',
    category:'Développement', level:'Débutant → Pro', duration:'12 semaines',
    icon:'💻', color:'#06D6A0',
    img:'https://images.unsplash.com/photo-1547658719-da2b51169166?w=700&q=80',
    description:'Créez des interfaces web modernes avec HTML5, CSS3, JavaScript ES6+, et les frameworks React & Vue.js. De débutant à développeur pro.',
    summary:['HTML5 — Structure et sémantique','CSS3 — Design et animations','Flexbox et CSS Grid','JavaScript ES6+ moderne','DOM manipulation et événements','Fetch API et JSON','React.js — Composants et Hooks','Déploiement et bonnes pratiques','Projets pratiques complets','Portfolio professionnel'],
    chapters:[
      {id:1,title:'HTML5 — Les Fondamentaux',lessons:[
        {id:1,title:'Structure d\'une page web HTML5',image:'https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&q=80',
         content:`HTML (HyperText Markup Language) est le squelette de toute page web. Sans HTML, pas de web.\n\n**Structure de base :**\n\`\`\`html\n<!DOCTYPE html>\n<html lang="fr">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Ma Page</title>\n</head>\n<body>\n  <h1>Mon Titre</h1>\n  <p>Mon paragraphe</p>\n</body>\n</html>\n\`\`\`\n\n**Les balises sémantiques HTML5 :**\n• \`<header>\` : En-tête du site\n• \`<nav>\` : Navigation\n• \`<main>\` : Contenu principal\n• \`<article>\` : Article indépendant\n• \`<section>\` : Section thématique\n• \`<aside>\` : Barre latérale\n• \`<footer>\` : Pied de page`},
        {id:2,title:'Formulaires HTML — Pratique',image:'https://images.unsplash.com/photo-1555421689-3f034debb7a6?w=800&q=80',
         content:`Les formulaires HTML permettent de collecter des données utilisateur.\n\n**Exemple de formulaire complet :**\n\`\`\`html\n<form action="/contact" method="POST">\n  <label for="nom">Nom :</label>\n  <input type="text" id="nom" name="nom" required placeholder="Votre nom" />\n\n  <label for="email">Email :</label>\n  <input type="email" id="email" name="email" required />\n\n  <label for="message">Message :</label>\n  <textarea id="message" name="message" rows="5"></textarea>\n\n  <button type="submit">Envoyer</button>\n</form>\n\`\`\`\n\n**Types d'input utiles :**\n• \`type="text"\` — texte libre\n• \`type="email"\` — email validé\n• \`type="password"\` — mot de passe masqué\n• \`type="tel"\` — numéro de téléphone\n• \`type="number"\` — nombre\n• \`type="file"\` — upload de fichier`},
        {id:3,title:'Images, liens et médias',image:'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&q=80',
         content:`**Images en HTML :**\n\`\`\`html\n<img src="photo.jpg" alt="Description de l'image" width="400" height="300" loading="lazy" />\n\`\`\`\n\nL'attribut \`alt\` est obligatoire pour l'accessibilité et le SEO.\n\n**Liens :**\n\`\`\`html\n<!-- Lien interne -->\n<a href="contact.html">Contact</a>\n\n<!-- Lien externe (ouvre dans nouvel onglet) -->\n<a href="https://google.com" target="_blank" rel="noopener">Google</a>\n\n<!-- Lien email -->\n<a href="mailto:contact@exemple.com">Email</a>\n\n<!-- Lien WhatsApp -->\n<a href="https://wa.me/2290159609581">WhatsApp</a>\n\`\`\`\n\n**Vidéo intégrée :**\n\`\`\`html\n<video controls width="640">\n  <source src="video.mp4" type="video/mp4" />\n</video>\n\`\`\``},
      ]},
      {id:2,title:'CSS3 — Design & Style',lessons:[
        {id:4,title:'Sélecteurs, propriétés et box model',image:'https://images.unsplash.com/photo-1523437113738-bbd3cc89fb19?w=800&q=80',
         content:`CSS contrôle l'apparence de chaque élément HTML.\n\n**Les sélecteurs CSS :**\n\`\`\`css\n/* Élément */\np { color: blue; }\n\n/* Classe (réutilisable) */\n.carte { background: white; }\n\n/* ID (unique) */\n#header { height: 80px; }\n\n/* Pseudo-classe */\na:hover { color: red; }\n\n/* Enfant direct */\n.nav > li { display: inline-block; }\n\`\`\`\n\n**Le Box Model :**\nChaque élément HTML est une boîte avec :\n• \`content\` : le contenu\n• \`padding\` : espace intérieur\n• \`border\` : bordure\n• \`margin\` : espace extérieur\n\n\`\`\`css\n.boite {\n  width: 300px;\n  padding: 20px;\n  border: 2px solid black;\n  margin: 10px;\n  box-sizing: border-box; /* Très important ! */\n}\n\`\`\``},
        {id:5,title:'Flexbox — Mise en page moderne',image:'https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=800&q=80',
         content:`Flexbox est la méthode moderne de mise en page CSS. Elle résout 90% des problèmes de mise en page.\n\n**Activer Flexbox :**\n\`\`\`css\n.container {\n  display: flex;\n  flex-direction: row; /* ou column */\n  justify-content: space-between; /* axe principal */\n  align-items: center; /* axe secondaire */\n  gap: 16px;\n  flex-wrap: wrap; /* retour à la ligne */\n}\n\`\`\`\n\n**Centrage parfait (horizontal + vertical) :**\n\`\`\`css\n.centre {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  min-height: 100vh;\n}\n\`\`\`\n\n**Navigation responsive :**\n\`\`\`css\nnav {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 0 24px;\n  height: 70px;\n}\n\`\`\``},
        {id:6,title:'CSS Grid et Responsive Design',image:'https://images.unsplash.com/photo-1550439062-609e1531270e?w=800&q=80',
         content:`CSS Grid est parfait pour les mises en page en 2 dimensions.\n\n**Grille de base :**\n\`\`\`css\n.grille {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 24px;\n}\n\`\`\`\n\n**Media Queries — Responsive Design :**\n\`\`\`css\n/* Desktop */\n.grille { grid-template-columns: repeat(3, 1fr); }\n\n/* Tablette */\n@media (max-width: 768px) {\n  .grille { grid-template-columns: repeat(2, 1fr); }\n}\n\n/* Mobile */\n@media (max-width: 480px) {\n  .grille { grid-template-columns: 1fr; }\n}\n\`\`\`\n\n**Variables CSS :**\n\`\`\`css\n:root {\n  --primary: #00B4D8;\n  --text: #1A1A2E;\n  --radius: 12px;\n}\n\n.bouton {\n  background: var(--primary);\n  border-radius: var(--radius);\n}\n\`\`\``},
      ]},
      {id:3,title:'JavaScript ES6+ Moderne',lessons:[
        {id:7,title:'Variables, fonctions et tableaux',image:'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=800&q=80',
         content:`JavaScript est le langage de programmation du web. Il rend vos pages interactives.\n\n**Variables modernes :**\n\`\`\`javascript\nconst nom = 'Luc'; // constante (ne change pas)\nlet age = 25;      // variable (peut changer)\n\n// Évitez var (ancien, plein de bugs)\n\`\`\`\n\n**Fonctions :**\n\`\`\`javascript\n// Fonction classique\nfunction saluer(prenom) {\n  return 'Bonjour ' + prenom + ' !';\n}\n\n// Fonction fléchée (ES6+)\nconst saluer = (prenom) => \`Bonjour \${prenom} !\`;\n\nconsole.log(saluer('Marie')); // Bonjour Marie !\n\`\`\`\n\n**Tableaux et méthodes modernes :**\n\`\`\`javascript\nconst formations = ['Web Marketing', 'Frontend', 'Backend'];\n\n// Parcourir\nformations.forEach(f => console.log(f));\n\n// Filtrer\nconst cheres = prix.filter(p => p > 15000);\n\n// Transformer\nconst noms = formations.map(f => f.toUpperCase());\n\`\`\``},
        {id:8,title:'DOM Manipulation',image:'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?w=800&q=80',
         content:`Le DOM (Document Object Model) représente votre page HTML en objets JavaScript manipulables.\n\n**Sélectionner des éléments :**\n\`\`\`javascript\nconst titre = document.getElementById('titre');\nconst boutons = document.querySelectorAll('.btn');\nconst premier = document.querySelector('.carte');\n\`\`\`\n\n**Modifier le contenu :**\n\`\`\`javascript\ntexte.textContent = 'Nouveau texte';\ntexte.innerHTML = '<strong>Texte en gras</strong>';\nimage.src = 'nouvelle-image.jpg';\nelement.style.color = 'red';\n\`\`\`\n\n**Gérer les événements :**\n\`\`\`javascript\nbouton.addEventListener('click', () => {\n  alert('Bouton cliqué !');\n});\n\ninput.addEventListener('input', (e) => {\n  console.log(e.target.value);\n});\n\`\`\`\n\n**Créer des éléments dynamiquement :**\n\`\`\`javascript\nconst div = document.createElement('div');\ndiv.classList.add('carte');\ndiv.textContent = 'Nouvelle carte';\ndocument.body.appendChild(div);\n\`\`\``},
      ]},
      {id:4,title:'Fetch API & Projets',lessons:[
        {id:9,title:'Fetch API et JSON',image:'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&q=80',
         content:`Fetch API permet de communiquer avec des serveurs web depuis JavaScript.\n\n**Récupérer des données :**\n\`\`\`javascript\nasync function chargerDonnees() {\n  try {\n    const reponse = await fetch('https://api.exemple.com/data');\n    const data = await reponse.json();\n    console.log(data);\n  } catch (erreur) {\n    console.error('Erreur:', erreur);\n  }\n}\n\`\`\`\n\n**Envoyer des données (POST) :**\n\`\`\`javascript\nasync function envoyerFormulaire(formulaire) {\n  const reponse = await fetch('/api/contact', {\n    method: 'POST',\n    headers: { 'Content-Type': 'application/json' },\n    body: JSON.stringify(formulaire)\n  });\n  return reponse.json();\n}\n\`\`\`\n\n**localStorage — Sauvegarder des données localement :**\n\`\`\`javascript\nlocalStorage.setItem('user', JSON.stringify({ nom: 'Luc' }));\nconst user = JSON.parse(localStorage.getItem('user'));\n\`\`\``},
        {id:10,title:'Projet — Site web complet',image:'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=800&q=80',
         content:`Dans ce projet final, vous allez créer un site web professionnel complet.\n\n**Ce que vous allez construire :**\n✅ Page d'accueil avec hero section animée\n✅ Section "À propos" avec photo et biographie\n✅ Portfolio/Galerie de projets avec filtres\n✅ Formulaire de contact fonctionnel\n✅ Thème sombre/clair\n✅ 100% Responsive (mobile, tablette, desktop)\n✅ Déploiement sur Vercel ou Netlify\n\n**Technologies utilisées :**\n• HTML5 sémantique\n• CSS3 avec variables et animations\n• JavaScript vanilla ES6+\n• API de géolocalisation ou météo\n\n**Étapes du projet :**\n1. Wireframe (maquette sur papier)\n2. Structure HTML\n3. Design CSS\n4. Interactivité JS\n5. Tests sur mobile\n6. Déploiement en ligne`},
      ]},
    ]
  },
  {
    id:'dev-backend', title:'Développement Web Backend', price:25000, currency:'FCFA',
    category:'Développement', level:'Intermédiaire → Pro', duration:'14 semaines',
    icon:'⚙️', color:'#EF233C',
    img:'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=700&q=80',
    description:'Maîtrisez Node.js, PHP, bases de données SQL et NoSQL, APIs REST et GraphQL, authentification et déploiement de serveurs.',
    summary:['Introduction aux serveurs et HTTP','Node.js et Express.js','Bases de données SQL (MySQL/PostgreSQL)','MongoDB — Base de données NoSQL','APIs REST — Conception et développement','Authentification JWT et sessions','PHP et Laravel','Déploiement et DevOps basique','Sécurité et bonnes pratiques','Projets API complètes'],
    chapters:[
      {id:1,title:'Node.js & Express.js',lessons:[
        {id:1,title:'Introduction au Backend et Node.js',image:'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80',
         content:`Le backend est la partie invisible d'une application web. Il gère la logique métier, les bases de données et la sécurité.\n\n**Node.js :**\nNode.js permet d'utiliser JavaScript côté serveur. Avantages :\n• Même langage frontend et backend\n• Performances élevées (non-bloquant)\n• Écosystème npm immense\n\n**Créer un serveur Node.js basique :**\n\`\`\`javascript\nconst http = require('http');\n\nconst server = http.createServer((req, res) => {\n  res.writeHead(200, { 'Content-Type': 'text/plain' });\n  res.end('Hello World!');\n});\n\nserver.listen(3000, () => {\n  console.log('Serveur démarré sur http://localhost:3000');\n});\n\`\`\`\n\n**Express.js — Framework pour simplifier :**\n\`\`\`javascript\nconst express = require('express');\nconst app = express();\n\napp.get('/', (req, res) => {\n  res.json({ message: 'Bienvenue sur mon API !' });\n});\n\napp.listen(3000);\n\`\`\``},
        {id:2,title:'Créer une API REST complète',image:'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?w=800&q=80',
         content:`Une API REST (Representational State Transfer) est une interface standardisée pour les communications client-serveur.\n\n**Les méthodes HTTP :**\n• GET — Lire des données\n• POST — Créer une ressource\n• PUT — Mettre à jour entièrement\n• PATCH — Mettre à jour partiellement\n• DELETE — Supprimer\n\n**API CRUD pour des utilisateurs :**\n\`\`\`javascript\n// Lister tous les utilisateurs\napp.get('/api/users', async (req, res) => {\n  const users = await User.find();\n  res.json(users);\n});\n\n// Créer un utilisateur\napp.post('/api/users', async (req, res) => {\n  const user = new User(req.body);\n  await user.save();\n  res.status(201).json(user);\n});\n\n// Supprimer\napp.delete('/api/users/:id', async (req, res) => {\n  await User.findByIdAndDelete(req.params.id);\n  res.json({ message: 'Supprimé' });\n});\n\`\`\``},
      ]},
      {id:2,title:'Bases de Données',lessons:[
        {id:3,title:'SQL avec MySQL — Guide complet',image:'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&q=80',
         content:`SQL est le langage standard pour les bases de données relationnelles.\n\n**Créer une table :**\n\`\`\`sql\nCREATE TABLE utilisateurs (\n  id INT AUTO_INCREMENT PRIMARY KEY,\n  nom VARCHAR(100) NOT NULL,\n  email VARCHAR(255) UNIQUE NOT NULL,\n  mot_de_passe VARCHAR(255) NOT NULL,\n  cree_le TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\`\`\`\n\n**Requêtes essentielles :**\n\`\`\`sql\n-- Insérer\nINSERT INTO utilisateurs (nom, email) VALUES ('Luc', 'luc@mail.com');\n\n-- Sélectionner\nSELECT * FROM utilisateurs WHERE id = 1;\n\n-- Mettre à jour\nUPDATE utilisateurs SET nom = 'Luc D.' WHERE id = 1;\n\n-- Supprimer\nDELETE FROM utilisateurs WHERE id = 1;\n\n-- Jointure\nSELECT u.nom, c.titre\nFROM utilisateurs u\nJOIN commandes c ON u.id = c.user_id;\n\`\`\``},
        {id:4,title:'MongoDB — Base de données NoSQL',image:'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
         content:`MongoDB est une base de données NoSQL orientée documents JSON. Parfaite pour les données flexibles.\n\n**Connexion avec Mongoose :**\n\`\`\`javascript\nconst mongoose = require('mongoose');\nawait mongoose.connect('mongodb://localhost/luckily');\n\n// Définir un schéma\nconst userSchema = new mongoose.Schema({\n  nom: { type: String, required: true },\n  email: { type: String, unique: true, required: true },\n  formations: [String], // tableau\n  creeLe: { type: Date, default: Date.now }\n});\n\nconst User = mongoose.model('User', userSchema);\n\`\`\`\n\n**Opérations CRUD MongoDB :**\n\`\`\`javascript\n// Créer\nconst user = await User.create({ nom: 'Luc', email: 'luc@mail.com' });\n\n// Lire\nconst users = await User.find({ role: 'etudiant' });\nconst user  = await User.findById(id);\n\n// Mettre à jour\nawait User.findByIdAndUpdate(id, { nom: 'Nouveau Nom' });\n\n// Supprimer\nawait User.findByIdAndDelete(id);\n\`\`\``},
      ]},
    ]
  },
  {
    id:'analyse-donnees', title:'Analyse des Données', price:15000, currency:'FCFA',
    category:'Data', level:'Débutant → Pro', duration:'10 semaines',
    icon:'📊', color:'#4CC9F0',
    img:'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=700&q=80',
    description:'Transformez les données brutes en insights précieux : Excel avancé, Python (Pandas, NumPy), visualisation, tableaux de bord et Business Intelligence.',
    summary:['Introduction à la Data Analyse','Excel avancé — Formules et TCD','Power Query et Power Pivot','Python pour la Data (Pandas, NumPy)','Visualisation avec Matplotlib et Seaborn','Tableaux de bord avec Power BI','SQL pour les analystes','Statistiques descriptives','Rapport d\'analyse professionnel','Projets réels'],
    chapters:[
      {id:1,title:'Excel pour l\'Analyse',lessons:[
        {id:1,title:'Tableaux croisés dynamiques (TCD)',image:'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&q=80',
         content:`Les tableaux croisés dynamiques (TCD) sont l'outil le plus puissant d'Excel pour analyser des données.\n\n**Créer un TCD :**\n1. Sélectionnez vos données\n2. Insertion → Tableau croisé dynamique\n3. Choisissez les champs :\n   • Lignes : Catégories (ex: Région)\n   • Colonnes : Périodes (ex: Mois)\n   • Valeurs : Chiffres (ex: Ventes)\n   • Filtres : Pour filtrer\n\n**Formules avancées indispensables :**\n\`\`\`\n=VLOOKUP(A2, Données!A:C, 2, FALSE)\n→ Recherche une valeur dans un tableau\n\n=SUMIF(B:B, "Marketing", C:C)\n→ Somme conditionnelle\n\n=COUNTIFS(A:A, ">18", B:B, "Actif")\n→ Compte avec plusieurs conditions\n\n=INDEX(A:A, MATCH(MAX(B:B), B:B, 0))\n→ Trouve la valeur associée au maximum\n\`\`\``},
        {id:2,title:'Python pour la Data — Pandas',image:'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80',
         content:`Pandas est la bibliothèque Python de référence pour la manipulation de données.\n\n**Charger et explorer des données :**\n\`\`\`python\nimport pandas as pd\nimport numpy as np\n\n# Charger un fichier CSV\ndf = pd.read_csv('ventes.csv')\n\n# Explorer les données\nprint(df.head())      # 5 premières lignes\nprint(df.info())      # Types de colonnes\nprint(df.describe())  # Statistiques\nprint(df.shape)       # (lignes, colonnes)\n\n# Filtrer\ndf_marketing = df[df['departement'] == 'Marketing']\n\n# Grouper\nventes_par_region = df.groupby('region')['ventes'].sum()\n\n# Créer une colonne\ndf['marge'] = df['prix'] - df['cout']\n\`\`\`\n\n**Nettoyer les données :**\n\`\`\`python\n# Supprimer les doublons\ndf = df.drop_duplicates()\n\n# Gérer les valeurs manquantes\ndf['age'].fillna(df['age'].mean(), inplace=True)\n\n# Changer le type\ndf['date'] = pd.to_datetime(df['date'])\n\`\`\``},
      ]},
    ]
  },
  {
    id:'word-debutant', title:'Microsoft Word — Débutant', price:5000, currency:'FCFA',
    category:'Informatique', level:'Débutant', duration:'2 semaines', icon:'📝', color:'#2B5CE6',
    img:'https://images.unsplash.com/photo-1618044619888-009e412ff12a?w=700&q=80',
    description:'Maîtrisez Word de A à Z : créer, formater, mettre en page et imprimer des documents professionnels avec aisance.',
    summary:['Découverte de l\'interface Word','Saisie et correction du texte','Mise en forme du texte','Paragraphes et alignements','Listes à puces et numérotées','Insertion d\'images et tableaux','Mise en page et impression','Enregistrement et partage'],
    chapters:[
      {id:1,title:'Découverte de Word',lessons:[
        {id:1,title:'L\'interface de Microsoft Word',image:'https://images.unsplash.com/photo-1618044619888-009e412ff12a?w=800&q=80',
         content:`Microsoft Word est le logiciel de traitement de texte le plus utilisé au monde avec plus d'1,2 milliard d'utilisateurs.\n\n**L'interface Word se compose de :**\n• Le Ruban (Ribbon) : contient tous les outils organisés en onglets\n• La Barre d'accès rapide : vos outils favoris\n• La Zone de travail : votre document\n• La Barre d'état : zoom, mode d'affichage\n\n**Les onglets principaux :**\n📌 Accueil — Police, paragraphe, styles\n📌 Insertion — Tableaux, images, formes\n📌 Mise en page — Marges, orientation, colonnes\n📌 Références — Table des matières, notes de bas de page\n📌 Révision — Orthographe, commentaires\n📌 Affichage — Zoom, règle, volets\n\n**Raccourcis essentiels :**\n• Ctrl+S : Enregistrer\n• Ctrl+Z : Annuler\n• Ctrl+C/V : Copier/Coller\n• Ctrl+B : Gras\n• Ctrl+P : Imprimer`},
        {id:2,title:'Mettre en forme le texte',image:'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&q=80',
         content:`La mise en forme est essentielle pour des documents professionnels et lisibles.\n\n**Mise en forme du caractère :**\n• Police : Times New Roman, Calibri, Arial\n• Taille : Corps (11-12pt), Titres (14-18pt)\n• Gras (Ctrl+G) : pour les titres et éléments importants\n• Italique (Ctrl+I) : pour les termes étrangers\n• Souligné (Ctrl+U) : à utiliser avec modération\n• Couleur : uniquement pour mettre en valeur\n\n**Mise en forme du paragraphe :**\n• Alignement : Gauche, Centré, Droite, Justifié\n• Interligne : Simple, 1,5, Double\n• Espacement avant/après paragraphe\n• Retraits (indentation)\n\n**Conseil pro :** Utilisez les Styles plutôt que de formater manuellement. Cela garantit la cohérence de tout votre document !`},
      ]},
      {id:2,title:'Tableaux et Images',lessons:[
        {id:3,title:'Insérer et formater des tableaux',image:'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?w=800&q=80',
         content:`Les tableaux permettent d'organiser des données de manière claire et professionnelle.\n\n**Créer un tableau :**\n1. Onglet Insertion → Tableau\n2. Choisissez le nombre de lignes et colonnes\n3. Ou utilisez "Insérer un tableau" pour préciser les dimensions\n\n**Mise en forme des tableaux :**\n• Sélectionnez un style dans "Outils de tableau → Création"\n• Fusionnez les cellules : sélectionnez → clic droit → Fusionner\n• Ajustez la largeur des colonnes en faisant glisser\n• Centrez le texte dans les cellules\n\n**Exemple de tableau professionnel :**\n| Formation | Durée | Prix |\n|-----------|-------|------|\n| Web Marketing | 8 semaines | 10.000 FCFA |\n| Dev Frontend | 12 semaines | 20.000 FCFA |\n\n**Convertir un tableau en texte :**\nSélectionnez → Outils de tableau → Disposition → Convertir en texte`},
      ]},
    ]
  },
  {
    id:'word-intermediaire', title:'Microsoft Word — Intermédiaire', price:5000, currency:'FCFA',
    category:'Informatique', level:'Intermédiaire', duration:'2 semaines', icon:'📄', color:'#2B5CE6',
    img:'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=700&q=80',
    description:'Approfondissez Word : styles, tables des matières automatiques, publipostage, en-têtes et pieds de page avancés.',
    summary:['Styles et thèmes Word','Table des matières automatique','En-têtes et pieds de page avancés','Publipostage (mail merge)','Protection de documents','Suivi des modifications','Modèles personnalisés','Insertion de champs automatiques'],
    chapters:[
      {id:1,title:'Styles et Documents Longs',lessons:[
        {id:1,title:'Maîtriser les styles Word',image:'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&q=80',
         content:`Les styles sont la fonctionnalité la plus puissante de Word pour les documents professionnels.\n\n**Qu'est-ce qu'un style ?**\nUn style est un ensemble de mises en forme prédéfinies applicables en un clic.\n\n**Styles intégrés essentiels :**\n• Titre 1 : Chapitres principaux (ex: "1. Introduction")\n• Titre 2 : Sous-sections (ex: "1.1 Contexte")\n• Titre 3 : Sous-sous-sections\n• Normal : Corps du texte\n• Citation : Pour les citations\n\n**Créer un style personnalisé :**\n1. Formatez un paragraphe comme vous le souhaitez\n2. Dans le volet Styles → Nouveau style\n3. Nommez votre style\n4. Choisissez le type : Paragraphe ou Caractère\n\n**Avantages des styles :**\n✅ Table des matières automatique\n✅ Modification globale en un clic\n✅ Navigation dans le document\n✅ Export PDF propre`},
        {id:2,title:'Table des matières automatique',image:'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?w=800&q=80',
         content:`Une table des matières automatique se génère en 3 secondes et se met à jour automatiquement.\n\n**Prérequis :** Utilisez les styles Titre 1, Titre 2, Titre 3 dans votre document.\n\n**Générer la table des matières :**\n1. Placez votre curseur où vous voulez la table\n2. Références → Table des matières\n3. Choisissez un style automatique\n\n**Mettre à jour la table :**\n• Clic droit → Mettre à jour les champs\n• Ou : Références → Mettre à jour la table\n\n**Personnaliser :**\n• Modifier les niveaux affichés\n• Changer le style des points de suite\n• Supprimer/ajouter les numéros de page\n\n**Numéros de page :**\nInsertion → Numéro de page → Position + Format`},
      ]},
    ]
  },
  {
    id:'word-avance', title:'Microsoft Word — Avancé', price:5000, currency:'FCFA',
    category:'Informatique', level:'Avancé', duration:'3 semaines', icon:'📋', color:'#2B5CE6',
    img:'https://images.unsplash.com/photo-1456324504439-367cee3b3c32?w=700&q=80',
    description:'Maîtrisez Word au niveau expert : macros VBA, formulaires interactifs, publipostage avancé et automatisation complète.',
    summary:['Macros Word — Introduction','VBA pour automatiser Word','Formulaires interactifs','Publipostage avancé avec conditions','Documents maîtres','Révision et co-édition','Scripts d\'automatisation','Intégration avec Excel et Outlook'],
    chapters:[
      {id:1,title:'Macros et Automatisation',lessons:[
        {id:1,title:'Introduction aux macros Word',image:'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=800&q=80',
         content:`Les macros permettent d'automatiser des tâches répétitives dans Word. Enregistrez une action une fois, exécutez-la à l'infini.\n\n**Enregistrer une macro :**\n1. Affichage → Macros → Enregistrer une macro\n2. Nommez votre macro (sans espaces)\n3. Choisissez un raccourci clavier ou un bouton\n4. Effectuez les actions à enregistrer\n5. Arrêtez l'enregistrement\n\n**Exemple de macro utile :**\nFormatage automatique d'un rapport d'entreprise :\n• Police Corps : Calibri 12pt\n• Interligne : 1.5\n• Marges : 2.5cm partout\n• En-tête avec logo et date\n\n**Accéder à l'éditeur VBA :**\nAlt+F11 → Éditeur Visual Basic\n\n\`\`\`vba\nSub FormaterDocument()\n    Selection.Font.Name = \"Calibri\"\n    Selection.Font.Size = 12\n    Selection.ParagraphFormat.LineSpacing = 18\nEnd Sub\n\`\`\``},
      ]},
    ]
  },
  {
    id:'excel-debutant', title:'Microsoft Excel — Débutant', price:5000, currency:'FCFA',
    category:'Informatique', level:'Débutant', duration:'2 semaines', icon:'📊', color:'#1A7F37',
    img:'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=700&q=80',
    description:'Prenez en main Excel : navigation, saisie de données, formules de base, graphiques simples et mise en forme des tableaux.',
    summary:['Interface et navigation Excel','Saisie et modification des données','Formules de base (SOMME, MOYENNE...)','Mise en forme des cellules','Tri et filtrage des données','Graphiques simples','Impression et mise en page','Gestion des feuilles et classeurs'],
    chapters:[
      {id:1,title:'Découverte d\'Excel',lessons:[
        {id:1,title:'L\'interface Excel et la navigation',image:'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=800&q=80',
         content:`Excel est organisé en cellules, lignes et colonnes formant une grille.\n\n**Vocabulaire essentiel :**\n• Cellule : intersection d'une colonne et d'une ligne (ex: A1)\n• Plage : groupe de cellules (ex: A1:D10)\n• Feuille : onglet dans le classeur\n• Classeur : fichier Excel (.xlsx)\n\n**Navigation rapide :**\n• Ctrl+Fin : Dernière cellule utilisée\n• Ctrl+Home : Cellule A1\n• Ctrl+→ : Fin de la ligne de données\n• Ctrl+A : Tout sélectionner\n• F2 : Modifier la cellule active\n\n**La barre de formule :**\nAffiche le contenu de la cellule sélectionnée. Commencez toujours une formule par = (égal).\n\n**Formats de cellule :**\n• Nombre : 1234.56\n• Monétaire : 1 234 FCFA\n• Date : 26/04/2025\n• Pourcentage : 85%\n• Texte : "Luckily Academy"`},
        {id:2,title:'Formules et fonctions essentielles',image:'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
         content:`Les formules sont le cœur d'Excel. Elles calculent automatiquement.\n\n**Les fonctions incontournables :**\n\`\`\`\n=SOMME(A1:A10)\n→ Additionne toutes les valeurs de A1 à A10\n\n=MOYENNE(B2:B20)\n→ Calcule la moyenne\n\n=MAX(C:C) / =MIN(C:C)\n→ Trouve la valeur maximale / minimale\n\n=NB(D1:D50)\n→ Compte les cellules avec des nombres\n\n=NBVAL(E1:E100)\n→ Compte toutes les cellules non vides\n\n=SI(A1>100, "Objectif atteint", "Objectif non atteint")\n→ Condition simple\n\n=CONCATENER(A1, " ", B1)\n→ Fusionne du texte (ou =A1&" "&B1)\n\n=ARRONDI(A1, 2)\n→ Arrondi à 2 décimales\n\`\`\`\n\n**Erreurs courantes :**\n• #DIV/0! : Division par zéro\n• #REF! : Référence invalide\n• #N/A : Valeur non trouvée\n• ##### : Colonne trop étroite`},
      ]},
    ]
  },
  {
    id:'excel-intermediaire', title:'Microsoft Excel — Intermédiaire', price:5000, currency:'FCFA',
    category:'Informatique', level:'Intermédiaire', duration:'3 semaines', icon:'📈', color:'#1A7F37',
    img:'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=700&q=80',
    description:'Approfondissez Excel : VLOOKUP, INDEX-MATCH, tableaux structurés, graphiques avancés, mise en forme conditionnelle.',
    summary:['Fonctions de recherche (VLOOKUP, HLOOKUP)','INDEX et MATCH','Fonctions conditionnelles avancées','Mise en forme conditionnelle','Tableaux structurés Excel','Graphiques avancés et sparklines','Validation des données','Protection des feuilles'],
    chapters:[
      {id:1,title:'Formules de Recherche',lessons:[
        {id:1,title:'VLOOKUP — La recherche verticale',image:'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&q=80',
         content:`VLOOKUP (RECHERCHEV en français) est l'une des fonctions les plus utilisées en entreprise.\n\n**Syntaxe :**\n\`\`\`\n=VLOOKUP(valeur_cherchée; tableau; numéro_colonne; [correspondance])\n\`\`\`\n\n**Exemple concret :**\nVous avez une liste de produits avec leurs prix dans Feuille2 (colonne A: Code produit, colonne B: Prix).\nDans Feuille1, vous voulez afficher le prix du produit dont le code est en A2 :\n\`\`\`\n=VLOOKUP(A2, Feuille2!A:B, 2, FALSE)\n\`\`\`\n• A2 = ce qu'on cherche\n• Feuille2!A:B = où chercher\n• 2 = numéro de la colonne à retourner\n• FALSE = correspondance exacte\n\n**INDEX + MATCH (plus puissant) :**\n\`\`\`\n=INDEX(B:B, MATCH(A2, A:A, 0))\n\`\`\`\nAvantage : cherche dans n'importe quelle direction`},
      ]},
    ]
  },
  {
    id:'excel-avance', title:'Microsoft Excel — Avancé', price:5000, currency:'FCFA',
    category:'Informatique', level:'Avancé', duration:'3 semaines', icon:'📉', color:'#1A7F37',
    img:'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=700&q=80',
    description:'Maîtrisez Excel niveau expert : Power Query, tableaux croisés avancés, VBA, macros et dashboards professionnels.',
    summary:['Power Query — Transformation de données','TCD avancés et segments','Macros et VBA Excel','Fonctions matricielles','Tableaux de bord (Dashboards)','Analyse de simulation','Résolution et solveur','Connexions à des sources externes'],
    chapters:[
      {id:1,title:'Power Query & VBA',lessons:[
        {id:1,title:'Power Query — Transformer les données',image:'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
         content:`Power Query est l'outil de transformation de données intégré dans Excel depuis 2016.\n\n**Accéder à Power Query :**\nDonnées → Obtenir et transformer les données → Obtenir les données\n\n**Ce que vous pouvez faire :**\n• Importer des données (CSV, JSON, web, bases de données)\n• Nettoyer les données (supprimer doublons, corriger formats)\n• Transformer (pivoter, dé-pivoter, fusionner)\n• Combiner plusieurs fichiers\n\n**Exemple — Nettoyer un fichier CSV :**\n1. Données → À partir d'un fichier CSV\n2. Dans Power Query :\n   • Supprimer les colonnes inutiles\n   • Changer les types (texte → date)\n   • Filtrer les lignes vides\n   • Renommer les colonnes\n3. Fermer & Charger → vos données sont propres !\n\n**Macro VBA Excel basique :**\n\`\`\`vba\nSub RapportAutomatique()\n    ' Sélectionner les données\n    Range("A1").CurrentRegion.Select\n    ' Créer un graphique\n    ActiveSheet.Shapes.AddChart2(201, xlColumnClustered)\n    ' Sauvegarder\n    ActiveWorkbook.Save\nEnd Sub\n\`\`\``},
      ]},
    ]
  },
  {
    id:'outils-compatibilite', title:'Outils de Compatibilité & Bureautique', price:5000, currency:'FCFA',
    category:'Informatique', level:'Tous niveaux', duration:'2 semaines', icon:'🔧', color:'#6C757D',
    img:'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=700&q=80',
    description:'Maîtrisez l\'écosystème bureautique complet : PDF, Google Workspace, LibreOffice, conversion de formats et outils de collaboration.',
    summary:['Créer et éditer des PDF','Adobe Reader et Acrobat','Google Docs, Sheets, Slides','LibreOffice — Alternative gratuite','Conversion entre formats','OneDrive et Google Drive','Outils de collaboration','Signatures électroniques'],
    chapters:[
      {id:1,title:'PDF et Google Workspace',lessons:[
        {id:1,title:'Maîtriser les PDF',image:'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=800&q=80',
         content:`Le PDF (Portable Document Format) est le standard mondial pour partager des documents.\n\n**Créer un PDF :**\n• Depuis Word/Excel : Fichier → Enregistrer sous → PDF\n• Depuis Chrome : Imprimer → Enregistrer en PDF\n• Depuis mobile : Imprimer → Enregistrer en PDF\n\n**Éditer un PDF gratuitement :**\n• ilovepdf.com — Fusionner, diviser, compresser\n• smallpdf.com — Édition basique\n• PDF24.org — Suite complète gratuite\n• Google Drive — Ouvrir et éditer le texte\n\n**Compresser un PDF :**\n→ ilovepdf.com → Compresser PDF\n\n**Sécuriser un PDF (mot de passe) :**\n→ ilovepdf.com → Protéger PDF\n\n**Convertir PDF → Word :**\n→ ilovepdf.com → PDF en Word`},
        {id:2,title:'Google Workspace — Suite collaborative',image:'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=800&q=80',
         content:`Google Workspace (anciennement G Suite) est la suite bureautique collaborative de Google, 100% gratuite dans sa version de base.\n\n**Les applications essentielles :**\n\n📄 **Google Docs** (équivalent Word)\n• Édition collaborative en temps réel\n• Commentaires et suggestions\n• Historique des versions\n• Export Word, PDF\n\n📊 **Google Sheets** (équivalent Excel)\n• Formules identiques à Excel\n• Tableaux croisés dynamiques\n• Graphiques interactifs\n• Connexion à des données web\n\n📊 **Google Slides** (équivalent PowerPoint)\n• Présentations professionnelles\n• Thèmes et animations\n• Présentation en ligne\n\n📁 **Google Drive**\n• 15 Go de stockage gratuit\n• Partage avec contrôle d'accès\n• Synchronisation multi-appareils\n\n**Avantage majeur :** Pas de logiciel à installer, accessible depuis n'importe quel appareil avec internet.`},
      ]},
    ]
  },
];

/* ════════ IMAGES FALLBACK ════════ */
const IMG_FB = 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=700&q=80';

function getCourseById(id){ return COURSES_DATA.find(c=>c.id===id)||null; }

function formatPrice(p){ return Number(p).toLocaleString('fr-FR')+' FCFA'; }

function getTotalLessons(c){
  if(!c?.chapters) return 0;
  return c.chapters.reduce((s,ch)=>s+(ch.lessons?.length||0),0);
}

/* ════════ CARTE COURS ════════ */
function courseCardHTML(c){
  const img = c.img || IMG_FB;
  const tot = getTotalLessons(c);
  return `
    <div class="course-card anim" data-id="${c.id}">
      <div class="cc-img">
        <img src="${img}" alt="${c.title}" loading="lazy" onerror="this.src='${IMG_FB}'"/>
        <div class="cc-overlay"></div>
        <div class="cc-badge">${c.level}</div>
        <div class="cc-icon">${c.icon}</div>
        <div class="cc-lock">🔒 Accès sécurisé</div>
      </div>
      <div class="cc-body">
        <div class="cc-cat">${c.category}</div>
        <h3 class="cc-title">${c.title}</h3>
        <div class="cc-meta">
          <span>⏱ ${c.duration}</span>
          <span>📚 ${tot} leçon${tot>1?'s':''}</span>
        </div>
        <p class="cc-desc">${c.description}</p>
        <div class="cc-foot">
          <div class="cc-price">${formatPrice(c.price)} <small>/ formation</small></div>
          <div class="cc-btn">Voir →</div>
        </div>
      </div>
    </div>`;
}

/* ════════ PAGE ACCUEIL ════════ */
function renderCoursesPreview(){
  const el = document.getElementById('coursesPreview');
  if(!el) return;
  el.innerHTML = COURSES_DATA.slice(0,6).map(c=>courseCardHTML(c)).join('');
  el.querySelectorAll('.course-card').forEach(card=>{
    card.addEventListener('click',()=>{ window.location.href='course-detail.html?id='+card.dataset.id; });
  });
}

/* ════════ PAGE CATALOGUE ════════ */
function renderCoursesPage(){
  const el = document.getElementById('coursesGrid');
  if(!el) return;
  const cat = new URLSearchParams(window.location.search).get('cat')||'all';
  const list = cat==='all'? COURSES_DATA : COURSES_DATA.filter(c=>c.category===cat);

  if(!list.length){
    el.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--text-m);">Aucune formation dans cette catégorie.</div>';
  } else {
    el.innerHTML = list.map(c=>courseCardHTML(c)).join('');
    el.querySelectorAll('.course-card').forEach(card=>{
      card.addEventListener('click',()=>{ window.location.href='course-detail.html?id='+card.dataset.id; });
    });
  }

  document.querySelectorAll('.filter-btn').forEach(btn=>{
    btn.classList.toggle('active', btn.dataset.cat===cat||(cat==='all'&&btn.dataset.cat==='all'));
    const nb = btn.cloneNode(true);
    btn.parentNode.replaceChild(nb,btn);
    nb.addEventListener('click',()=>{
      const u=new URL(window.location.href);
      u.searchParams.set('cat',nb.dataset.cat);
      window.history.replaceState({},'',u);
      renderCoursesPage();
    });
  });
}

/* ════════ PAGE DÉTAIL FORMATION ════════ */
async function renderCourseDetail(){
  const id = new URLSearchParams(window.location.search).get('id');
  if(!id){ window.location.href='courses.html'; return; }
  const c = getCourseById(id);
  if(!c){ window.location.href='courses.html'; return; }

  document.title = c.title+' — Luckily Academy';

  const tot     = getTotalLessons(c);
  const session = (typeof getSession==='function')?getSession():null;
  const enrolled= session?(typeof isEnrolled==='function'?isEnrolled(session.userId,id):false):false;

  /* ── Hero ── */
  const heroEl = document.getElementById('courseHero');
  if(heroEl){
    heroEl.innerHTML=`
      <div class="course-hero-text">
        <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(0,180,216,.15);border:1px solid rgba(0,180,216,.3);color:var(--primary);padding:4px 12px;border-radius:99px;font-size:.74rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:14px;">${c.category} · ${c.level}</div>
        <h1 style="font-family:var(--ff-d);font-size:clamp(2rem,4vw,2.8rem);font-weight:700;color:#fff;margin-bottom:14px;line-height:1.2;">${c.icon} ${c.title}</h1>
        <p style="color:rgba(255,255,255,.72);font-size:.95rem;line-height:1.8;margin-bottom:22px;">${c.description}</p>
        <div style="display:flex;gap:20px;flex-wrap:wrap;">
          <span style="color:rgba(255,255,255,.6);font-size:.85rem;">⏱ ${c.duration}</span>
          <span style="color:rgba(255,255,255,.6);font-size:.85rem;">📚 ${tot} leçons</span>
          <span style="color:rgba(255,255,255,.6);font-size:.85rem;">📋 ${c.chapters.length} chapitres</span>
        </div>
      </div>
      <div class="course-purchase-card" style="background:var(--bg-card);border-radius:24px;padding:28px;box-shadow:var(--sh-xl);">
        <img src="${c.img||IMG_FB}" alt="${c.title}" style="width:100%;height:150px;object-fit:cover;border-radius:14px;margin-bottom:16px;" onerror="this.src='${IMG_FB}'" />
        <div style="font-family:var(--ff-d);font-size:2.2rem;font-weight:800;color:var(--text);margin-bottom:3px;">${formatPrice(c.price)}</div>
        <div style="font-size:.78rem;color:var(--text-m);margin-bottom:20px;">Accès à vie · Paiement unique</div>
        ${enrolled
          ?`<button onclick="window.location.href='lesson.html?course=${id}&chapter=0&lesson=0'" style="width:100%;padding:13px;border-radius:50px;background:linear-gradient(135deg,#06D6A0,#0096B5);color:#fff;font-weight:700;font-size:.95rem;cursor:pointer;border:none;margin-bottom:12px;">✓ Accéder au cours →</button>`
          :session
            ?`<button id="enrollBtn" onclick="openAccessModal('${id}')" style="width:100%;padding:13px;border-radius:50px;background:linear-gradient(135deg,var(--primary),var(--primary-d));color:#fff;font-weight:700;font-size:.95rem;cursor:pointer;border:none;margin-bottom:12px;">🎓 J'ai déjà payé — Entrer mon code</button>
               <button onclick="showPaymentModal('${id}','${session?.userId||''}')" style="width:100%;padding:11px;border-radius:50px;border:1.5px solid var(--primary);color:var(--primary);font-weight:600;font-size:.9rem;cursor:pointer;background:transparent;">💳 S'inscrire via WhatsApp</button>`
            :`<button onclick="window.location.href='auth.html?redirect=course-detail.html%3Fid%3D${id}'" style="width:100%;padding:13px;border-radius:50px;background:linear-gradient(135deg,var(--primary),var(--primary-d));color:#fff;font-weight:700;font-size:.95rem;cursor:pointer;border:none;">🔒 Se connecter pour s'inscrire</button>`
        }
        <div style="display:flex;flex-direction:column;gap:7px;margin-top:18px;padding-top:18px;border-top:1px solid var(--border);">
          <div style="display:flex;align-items:center;gap:8px;font-size:.83rem;color:var(--text-m);">✓ Accès à vie au contenu</div>
          <div style="display:flex;align-items:center;gap:8px;font-size:.83rem;color:var(--text-m);">✓ ${tot} leçons illustrées</div>
          <div style="display:flex;align-items:center;gap:8px;font-size:.83rem;color:var(--text-m);">✓ PDF téléchargeables</div>
          <div style="display:flex;align-items:center;gap:8px;font-size:.83rem;color:var(--text-m);">✓ Assistant IA 24h/24</div>
          <div style="display:flex;align-items:center;gap:8px;font-size:.83rem;color:var(--text-m);">✓ Certificat de complétion</div>
        </div>
      </div>`;
  }

  /* ── Sommaire ── */
  const sumEl = document.getElementById('courseSummary');
  if(sumEl && c.summary){
    sumEl.innerHTML=`<h2 style="font-family:var(--ff-d);font-size:1.5rem;font-weight:700;margin-bottom:18px;">📋 Sommaire de la formation</h2>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">
      ${c.summary.map((s,i)=>`
        <div style="display:flex;align-items:flex-start;gap:10px;padding:12px;background:var(--bg-alt);border-radius:10px;border:1px solid var(--border);">
          <span style="background:var(--primary);color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;flex-shrink:0;">${i+1}</span>
          <span style="font-size:.85rem;color:var(--text-m);line-height:1.4;">${s}</span>
        </div>`).join('')}
    </div>`;
  }

  /* ── Curriculum ── */
  const currEl = document.getElementById('courseCurriculum');
  if(currEl){
    currEl.innerHTML=`<h2 style="font-family:var(--ff-d);font-size:1.5rem;font-weight:700;margin-bottom:8px;">Programme détaillé</h2>
      <p style="color:var(--text-m);margin-bottom:24px;">${c.chapters.length} chapitre${c.chapters.length>1?'s':''} · ${tot} leçon${tot>1?'s':''}</p>
      ${c.chapters.map((ch,ci)=>`
        <div class="chapter-item ${ci===0?'open':''}" id="ch-${ci}" style="border:1px solid var(--border);border-radius:var(--r);margin-bottom:10px;overflow:hidden;">
          <div onclick="toggleChapter(${ci})" style="padding:16px 18px;display:flex;align-items:center;justify-content:space-between;background:var(--bg-alt);cursor:pointer;">
            <div>
              <div style="font-weight:700;font-size:.92rem;">Ch.${ci+1} — ${ch.title}</div>
              <div style="font-size:.75rem;color:var(--text-m);">${ch.lessons?.length||0} leçon${(ch.lessons?.length||0)>1?'s':''}</div>
            </div>
            <span id="ch-toggle-${ci}" style="transition:transform .3s;display:inline-block;${ci===0?'transform:rotate(180deg)':''}">▾</span>
          </div>
          <div id="ch-lessons-${ci}" style="${ci===0?'':'display:none;'}">
            ${(ch.lessons||[]).map((l,li)=>`
              <div onclick="${enrolled?`window.location.href='lesson.html?course=${id}&chapter=${ci}&lesson=${li}'`:`openAccessModal('${id}')`}"
                style="display:flex;align-items:center;gap:10px;padding:11px 18px;font-size:.86rem;color:var(--text-m);border-bottom:1px solid var(--border);cursor:pointer;transition:background .18s;"
                onmouseover="this.style.background='var(--bg-alt)'" onmouseout="this.style.background=''">
                <span>${enrolled?'▶':'🔒'}</span>
                <span style="flex:1;">${l.title}</span>
                ${!enrolled?'<span style="font-size:.7rem;color:var(--text-m);">Code requis</span>':''}
              </div>`).join('')}
          </div>
        </div>`).join('')}`;
  }

  /* ── PDF btn ── */
  const pdfBtn = document.getElementById('pdfBtn');
  if(pdfBtn && enrolled){ pdfBtn.disabled=false; pdfBtn.textContent='⬇ Télécharger le PDF'; }
}

function toggleChapter(i){
  const lessonsEl = document.getElementById('ch-lessons-'+i);
  const toggleEl  = document.getElementById('ch-toggle-'+i);
  if(!lessonsEl) return;
  const open = lessonsEl.style.display!=='none';
  lessonsEl.style.display = open?'none':'block';
  if(toggleEl) toggleEl.style.transform = open?'':'rotate(180deg)';
}

/* ════════ MODAL CODE D'ACCÈS ════════ */
function openAccessModal(courseId){
  const session = (typeof getSession==='function')?getSession():null;
  if(!session){
    window.location.href='auth.html?redirect=course-detail.html%3Fid%3D'+courseId;
    return;
  }
  // Créer le modal
  let m = document.getElementById('accessModal');
  if(m) m.remove();
  m = document.createElement('div');
  m.id='accessModal';
  m.className='modal-ov open';
  const c = getCourseById(courseId);
  m.innerHTML=`
    <div class="access-box">
      <div class="access-head">
        <div class="access-icon">${c?.icon||'🎓'}</div>
        <div class="access-title">${c?.title||'Formation'}</div>
        <div class="access-sub">Entrez votre code d'accès</div>
      </div>
      <div class="access-body">
        <p style="font-size:.85rem;color:var(--text-m);margin-bottom:16px;line-height:1.6;">Ce code vous a été envoyé par WhatsApp après confirmation de votre paiement par notre équipe.</p>
        <input type="text" id="accessCodeInput" class="access-code-inp" placeholder="Ex : luckily2002"
          autocomplete="off" style="margin-bottom:12px;" onkeypress="if(event.key==='Enter') submitAccessCode('${courseId}')" />
        <div class="access-err" id="accessErr">Code incorrect. Vérifiez ou contactez-nous.</div>
        <button onclick="submitAccessCode('${courseId}')" class="btn-access">🔓 Accéder à la formation</button>
        <div class="access-hint">Pas encore de code ? Inscrivez-vous via WhatsApp et payez pour recevoir votre code d'accès.</div>
        <div style="display:flex;gap:10px;margin-top:16px;justify-content:center;flex-wrap:wrap;">
          <a href="https://wa.me/2290159609581?text=Bonjour, je souhaite m'inscrire à la formation ${encodeURIComponent(c?.title||'')}" target="_blank"
            style="padding:9px 18px;border-radius:50px;background:#25D366;color:#fff;font-size:.82rem;font-weight:700;text-decoration:none;">💬 S'inscrire via WhatsApp</a>
          <button onclick="document.getElementById('accessModal').remove()" style="padding:9px 18px;border-radius:50px;border:1px solid var(--border);color:var(--text-m);font-size:.82rem;cursor:pointer;background:transparent;">Fermer</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(m);
  document.body.style.overflow='hidden';
  m.addEventListener('click',e=>{ if(e.target===m){ m.remove(); document.body.style.overflow=''; }});
  setTimeout(()=>document.getElementById('accessCodeInput')?.focus(),300);
}

function submitAccessCode(courseId){
  const input = document.getElementById('accessCodeInput');
  const errEl = document.getElementById('accessErr');
  if(!input) return;
  const code = input.value.trim();
  if(!code){ input.style.borderColor='#EF233C'; return; }

  const session = (typeof getSession==='function')?getSession():null;
  if(!session){ window.location.href='auth.html'; return; }

  if((typeof verifyCourseCode==='function') && verifyCourseCode(courseId, code)){
    // Inscrire l'utilisateur
    if(typeof enrollUser==='function') enrollUser(session.userId, courseId);
    // Fermer modal et accéder
    document.getElementById('accessModal')?.remove();
    document.body.style.overflow='';
    if(typeof showToast==='function') showToast('✓ Accès accordé ! Bienvenue dans la formation.','success');
    setTimeout(()=>{ window.location.href='lesson.html?course='+courseId+'&chapter=0&lesson=0'; },1200);
  } else {
    if(errEl){ errEl.style.display='block'; }
    input.style.borderColor='#EF233C';
    input.style.animation='shake .3s ease';
    setTimeout(()=>{ input.style.animation=''; },300);
  }
}

/* ════════ LEÇON ════════ */
async function renderLesson(){
  const p = new URLSearchParams(window.location.search);
  const courseId   = p.get('course');
  const chapterIdx = parseInt(p.get('chapter')||'0',10);
  const lessonIdx  = parseInt(p.get('lesson')||'0',10);

  const c = getCourseById(courseId);
  if(!c){ window.location.href='courses.html'; return; }

  const session = (typeof getSession==='function')?getSession():null;
  if(!session){ window.location.href='auth.html?redirect=lesson.html%3Fcourse%3D'+courseId+'%26chapter%3D'+chapterIdx+'%26lesson%3D'+lessonIdx; return; }

  const enrolled = (typeof isEnrolled==='function')?isEnrolled(session.userId,courseId):false;
  if(!enrolled){ window.location.href='course-detail.html?id='+courseId; return; }

  const ch = c.chapters[chapterIdx];
  const l  = ch?.lessons?.[lessonIdx];
  if(!l){ window.location.href='course-detail.html?id='+courseId; return; }

  document.title = l.title+' — '+c.title+' — Luckily Academy';

  const bcEl = document.getElementById('lessonBC');
  if(bcEl) bcEl.innerHTML=`<a href="courses.html">Formations</a> › <a href="course-detail.html?id=${courseId}">${c.title}</a> › <span>${l.title}</span>`;

  const titleEl = document.getElementById('lessonTitle');
  if(titleEl) titleEl.textContent=l.title;

  const imgEl = document.getElementById('lessonImg');
  if(imgEl){ if(l.image){ imgEl.src=l.image; imgEl.style.display='block'; imgEl.onerror=()=>{ imgEl.style.display='none'; }; } else { imgEl.style.display='none'; } }

  const bodyEl = document.getElementById('lessonBody');
  if(bodyEl){
    // Convertit le contenu texte en HTML formaté
    const html = (l.content||'')
      .replace(/```(\w*)\n?([\s\S]*?)```/g, (_,lang,code)=>`<pre style="background:var(--bg-alt);border:1px solid var(--border);border-radius:var(--r-sm);padding:16px;overflow-x:auto;margin:16px 0;font-family:monospace;font-size:.85rem;line-height:1.6;"><code>${code.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</code></pre>`)
      .replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>')
      .replace(/\n/g,'<br>');
    bodyEl.innerHTML=html;
  }

  // Mark complete btn
  const mcBtn = document.getElementById('markCompleteBtn');
  if(mcBtn){
    const prog = (typeof getLessonProgress==='function')?getLessonProgress(session.userId,courseId):[];
    const done = prog.includes(l.id);
    mcBtn.textContent = done?'✓ Leçon complétée':'Marquer comme complétée';
    mcBtn.style.background = done?'linear-gradient(135deg,#06D6A0,#0096B5)':'';
    mcBtn.onclick=()=>{
      if(typeof markLessonComplete==='function') markLessonComplete(session.userId,courseId,l.id);
      mcBtn.textContent='✓ Leçon complétée';
      mcBtn.style.background='linear-gradient(135deg,#06D6A0,#0096B5)';
      renderLessonSidebar(c,courseId,chapterIdx,lessonIdx,session.userId);
      if(typeof showToast==='function') showToast('✓ Leçon complétée !','success');
    };
  }

  // Nav
  const all=[];
  c.chapters.forEach((ch2,ci)=>(ch2.lessons||[]).forEach((_,li)=>all.push({ch:ci,les:li})));
  const cur=all.findIndex(x=>x.ch===chapterIdx&&x.les===lessonIdx);

  const prevBtn=document.getElementById('prevBtn');
  const nextBtn=document.getElementById('nextBtn');
  if(prevBtn){
    if(cur>0){ prevBtn.onclick=()=>{ window.location.href=`lesson.html?course=${courseId}&chapter=${all[cur-1].ch}&lesson=${all[cur-1].les}`; }; }
    else { prevBtn.style.opacity='.4'; prevBtn.disabled=true; }
  }
  if(nextBtn){
    if(cur<all.length-1){
      nextBtn.onclick=()=>{
        if(typeof markLessonComplete==='function') markLessonComplete(session.userId,courseId,l.id);
        window.location.href=`lesson.html?course=${courseId}&chapter=${all[cur+1].ch}&lesson=${all[cur+1].les}`;
      };
    } else {
      nextBtn.textContent='🏆 Formation terminée !';
      nextBtn.style.background='linear-gradient(135deg,#06D6A0,#0096B5)';
      nextBtn.onclick=()=>{ if(typeof markLessonComplete==='function') markLessonComplete(session.userId,courseId,l.id); window.location.href='course-detail.html?id='+courseId; };
    }
  }

  // Progress
  const tot=(typeof getTotalLessons==='function')?getTotalLessons(c):0;
  const pct=(typeof getCourseProgressPct==='function')?getCourseProgressPct(session.userId,courseId,tot):0;
  const pFill=document.getElementById('progressFill');
  const pTxt=document.getElementById('progressTxt');
  if(pFill) pFill.style.width=pct+'%';
  if(pTxt) pTxt.textContent=pct+'% complété';
  const topTitle=document.getElementById('topbarTitle');
  if(topTitle) topTitle.textContent=c.title;

  renderLessonSidebar(c,courseId,chapterIdx,lessonIdx,session.userId);
}

function renderLessonSidebar(c,courseId,curCh,curLes,userId){
  const el=document.getElementById('lessonSidebar');
  if(!el) return;
  const prog=(typeof getLessonProgress==='function')?getLessonProgress(userId,courseId):[];
  let html='<div class="ls-title">Contenu du cours</div><div class="ls-list">';
  c.chapters.forEach((ch,ci)=>{
    html+=`<div class="ls-ch-hd">Ch.${ci+1} — ${ch.title}</div>`;
    (ch.lessons||[]).forEach((l,li)=>{
      const active=ci===curCh&&li===curLes;
      const done=prog.includes(l.id);
      html+=`<div class="ls-item ${active?'active':''} ${done?'done':''}"
        onclick="window.location.href='lesson.html?course=${courseId}&chapter=${ci}&lesson=${li}'"
        style="${active?'background:var(--primary-l);color:var(--primary);font-weight:700;':''}" >
        <span>${done?'✓':active?'▶':'○'}</span>
        <span style="flex:1;font-size:.8rem;">${l.title}</span>
      </div>`;
    });
  });
  html+='</div>';
  el.innerHTML=html;
}

/* ════════ DASHBOARD ════════ */
async function renderDashboard(){
  const session=(typeof getSession==='function')?getSession():null;
  if(!session){ window.location.href='auth.html'; return; }
  const user=(typeof getCurrentUser==='function')?getCurrentUser():null;

  const fname=(user?.fullname||'Étudiant').split(' ')[0];
  const wEl=document.getElementById('dashWelcome');
  if(wEl) wEl.textContent=`Bonjour, ${fname} 👋`;

  const sAv=document.getElementById('sbAvatar'); if(sAv) sAv.textContent=(user?.fullname||'U').charAt(0).toUpperCase();
  const sNm=document.getElementById('sbName');   if(sNm) sNm.textContent=user?.fullname||'';
  const sEm=document.getElementById('sbEmail');  if(sEm) sEm.textContent=user?.email||'';
  const nAv=document.getElementById('navAvatar'); if(nAv) nAv.textContent=(user?.fullname||'U').charAt(0).toUpperCase();

  const ids=(typeof getUserCourses==='function')?getUserCourses(session.userId):[];
  const enrolled=COURSES_DATA.filter(c=>ids.includes(c.id));

  const sC=document.getElementById('statCourses'); if(sC) sC.textContent=enrolled.length;

  let totalPct=0,certs=0,totalDone=0;
  enrolled.forEach(c=>{
    const tot=getTotalLessons(c);
    const pct=(typeof getCourseProgressPct==='function')?getCourseProgressPct(session.userId,c.id,tot):0;
    const done=(typeof getLessonProgress==='function')?getLessonProgress(session.userId,c.id).length:0;
    totalPct+=pct; totalDone+=done;
    if(pct===100) certs++;
  });
  const avg=enrolled.length?Math.round(totalPct/enrolled.length):0;
  const sP=document.getElementById('statProg');   if(sP) sP.textContent=avg+'%';
  const sCe=document.getElementById('statCerts'); if(sCe) sCe.textContent=certs;
  const sT=document.getElementById('statTime');   if(sT) sT.textContent=Math.round(totalDone*.5)+'h';

  const grid=document.getElementById('enrolledGrid');
  if(!grid) return;
  if(!enrolled.length){
    grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:var(--text-m);">
      <div style="font-size:2.8rem;margin-bottom:14px;">📚</div>
      <p style="margin-bottom:20px;">Vous n'êtes inscrit(e) à aucune formation pour l'instant.</p>
      <a href="courses.html" class="btn-primary">Explorer les formations →</a>
    </div>`;
    return;
  }
  grid.innerHTML=enrolled.map(c=>{
    const tot=getTotalLessons(c);
    const pct=(typeof getCourseProgressPct==='function')?getCourseProgressPct(session.userId,c.id,tot):0;
    const done=(typeof getLessonProgress==='function')?getLessonProgress(session.userId,c.id).length:0;
    return `<div class="en-card" onclick="window.location.href='course-detail.html?id=${c.id}'">
      <div class="en-icon">${c.icon}</div>
      <div class="en-title">${c.title}</div>
      <div class="en-sub">${c.category} · ${c.level}</div>
      <div class="prog-bar"><div class="prog-fill" style="width:${pct}%"></div></div>
      <div class="prog-txt">${done}/${tot} leçons · ${pct}%</div>
      <a href="lesson.html?course=${c.id}&chapter=0&lesson=0" class="btn-cont" onclick="event.stopPropagation()">${pct>0?'▶ Continuer':'🚀 Commencer'}</a>
    </div>`;
  }).join('');
}
